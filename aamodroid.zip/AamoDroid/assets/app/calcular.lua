-- Fatora��o com o Crivo de Erat�stenes
-- Cleuton Sampaio, Julho de 2012

function erato(n)
  local t = {0, 2}
  for i = 3, n, 2 do t[i], t[i+1] = i, 0 end
  for i = 3, math.sqrt(n) do for j = i*i, n, 2*i do t[j] = 0 end end
  return t
end

function getPrimo()
	local nprimo = 0
	ind = ind + 1

	while tabela[ind] ~= nil do
		if tabela[ind] ~= 0 then
			nprimo = tabela[ind]		
			break
		else		
			ind = ind + 1
		end
	end
	if tabela[ind] == nil then
		nprimo = numero
	end
	return nprimo
end


function calcular()
  	local res = numero
  	ind = 0
  	local primo = getPrimo()
  	local result = ""

  	while res > 1 do
		local resto = math.fmod(res,primo)
		if resto > 0 then
			primo = getPrimo()
		else
			result = result .. " "
			res = res / primo
			if res == 1 then
				primo = primo * sinalUltimo;
			end
			result = result .. primo
		end
  	end

  	return result
 
end

numero = tonumber(aamo.getTextField(3))
local resultado = tostring(numero)

if numero >= 3 then
	if numero < 0 then
		sinalUltimo = -1;
		numero = numero * (-1);
	else
		sinalUltimo = 1;
	end
	tabela = erato(numero)
	resultado = calcular()
end

aamo.showMessage(resultado)


