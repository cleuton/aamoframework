package com.machinapp.runtime.desktop;

import java.io.File;

import javax.swing.JFileChooser;

import com.machinapp.runtime.desktop.util.Context;

public class DesktopRuntime {
	public static void start(String appPath) {
		File mainPath = new File(appPath);
		if (!mainPath.exists()) {
			JFileChooser chooser = new JFileChooser();
			chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		    int returnVal = chooser.showOpenDialog(null);
		    if(!(returnVal == JFileChooser.APPROVE_OPTION)) {
		    	return;
		    }
		}
		AamoDroidActivity screen = new AamoDroidActivity();
		screen.context = getContext(mainPath);
		screen.context.setAppTitle("Test MachinApp");
		screen.show();
	}
	
	private static Context getContext(File mainPath) {
		Context context = new Context();
		context.setAppPath(mainPath);
		File dbPath = new File(mainPath.getPath() + "/app/bd");
		context.setDbPath(dbPath);
		
		return context;
	}
}
