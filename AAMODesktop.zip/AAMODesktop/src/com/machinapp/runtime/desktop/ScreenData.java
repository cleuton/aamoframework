package com.machinapp.runtime.desktop;

import java.util.List;

import javax.swing.JComponent;


//import android.widget.RelativeLayout; -> JComponent


public class ScreenData {
	public int uiid;
    public String title;
    public String onLoadScript;
    public String onEndScript; 
    public String onLeaveScript;
    public String onBackScript;
    public JComponent dvLayout;
    public List<String> menuOptions;
    public String onMenuSelected;
    public int bgColor;
}
