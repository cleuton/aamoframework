package com.machinapp.runtime.desktop.util;

import java.io.File;

public class Context {
	private File appPath;
	private File dbPath;
	private int screenWidth;
	private int screenHeight;
	private String appTitle;
	
	public String getAppTitle() {
		return appTitle;
	}
	public void setAppTitle(String appTitle) {
		this.appTitle = appTitle;
	}
	public File getAppPath() {
		return appPath;
	}
	public void setAppPath(File appPath) {
		this.appPath = appPath;
	}
	public File getDbPath() {
		return dbPath;
	}
	public void setDbPath(File dbPath) {
		this.dbPath = dbPath;
	}
	
	public int getScreenWidth() {
		return screenWidth;
	}
	public void setScreenWidth(int screenWidth) {
		this.screenWidth = screenWidth;
	}
	public int getScreenHeight() {
		return screenHeight;
	}
	public void setScreenHeight(int screenHeight) {
		this.screenHeight = screenHeight;
	}
	public String getDatabasePath(String dbname) {
		String returnPath = null;
		if (dbname.indexOf(".db") < 0) {
			dbname += ".db";
		}
		returnPath = dbPath + "/" + dbname;
		File dbase = new File(returnPath);
		if (!dbase.exists()) {
			returnPath = null;
		}
		return returnPath;
	}
	
	public Context() {
		this.screenHeight = 480;
		this.screenWidth = 320;
	}
	
}
