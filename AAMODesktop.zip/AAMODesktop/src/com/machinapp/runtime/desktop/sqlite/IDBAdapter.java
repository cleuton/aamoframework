package com.machinapp.runtime.desktop.sqlite;

import java.sql.ResultSet;
import java.util.List;

import com.machinapp.runtime.desktop.util.Context;

//import android.database.Cursor; -> ResultSet

/**
 * DAO Interface.
 * 
 * @author thecodebakers@gmail.com
 *
 */
public interface IDBAdapter {
	
	/**
	 * execute a query
	 *  
	 * @param sql - sql command
	 * @param params - parameters query
	 * 
	 * @return cursor
	 */
	public abstract ResultSet query(String sql, List<String> params);
		
	
	/**
	 * Execute a SQL statement  
	 * 
	 * @param sql  - sql command
	 * @param params - parameters query
	 */
	public void execSQL (String sql, List<String> params);
	
	/**
	 * Database version
	 * 
	 * @return int 
	 */
	public int getDatabaseVersion();
	
	/**
	 * open the database
	 * @param nome
	 */
	public void openDatabase (String nome);
	
	/**
	 * close the database
	 * @param nome
	 */
	public void closeDatabase (String nome);
	
}