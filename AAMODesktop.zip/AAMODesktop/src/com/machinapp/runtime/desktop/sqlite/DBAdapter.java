package com.machinapp.runtime.desktop.sqlite;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.machinapp.runtime.desktop.AamoException;
import com.machinapp.runtime.desktop.sqlite.model.Database;

//import android.database.Cursor; -> ResultSet
//import android.database.sqlite.SQLiteDatabase;
import com.machinapp.runtime.desktop.util.Context;
import com.machinapp.runtime.desktop.util.Log;

public class DBAdapter implements IDBAdapter {
	
	private static Connection db = null;
	private DBHelper dbHelper= null;
	private static final String TAG = "DBAdapter";
	private static Context ctx = null;
	private static Database database = null;
	
	public DBAdapter(Context context) {
		Database database = readXML (context);
		
		ctx = context;
    }
	
	private Database readXML(Context context){
		
		DBParser parser = new DBParser(context);
		Database base = null;
		try {
			base = parser.readXMLDatabase(context);
		} catch (AamoException e) {
			Log.d(TAG, e.getMessage());
		} catch (Exception ex){
			Log.d(TAG, ex.getMessage());
		}
		parser = null;
		
		return base;
	}
	
	public ResultSet query(String sql, List<String> params) {
		
		//db = dbHelper.getReadableDatabase();
		
		int pindex = 1;
		ResultSet cursor = null;
		try {
			PreparedStatement pstmt = db.prepareStatement(sql);
			for (String param : params) {
				pstmt.setString(pindex++, param);
			}
			cursor = pstmt.executeQuery();
			cursor.first();
		} catch (SQLException e) {
			Log.e("DBAdapter", "Erro ao executar query> " + e.getMessage());
		}
        
        
        return cursor;
	}
	
	public void execSQL (String sql, List<String> params){ 
		int pindex = 1;
		try {
			PreparedStatement pstmt = db.prepareStatement(sql);
			for (String param : params) {
				pstmt.setString(pindex++, param);
			}
			pstmt.executeUpdate();
		}
		catch (SQLException e) {
			Log.e("DBAdapter", "Erro ao executar SQL> " + e.getMessage());
		}
		
	}
	
	public void openDatabase (String nome){
		if (database == null){
			database = readXML (ctx);
		}	
		dbHelper = new DBHelper(ctx, database);
		if (db == null){
			db = dbHelper.getWritableDatabase();
		}	
	}
	
	public void closeDatabase (String nome){
		if (db != null){
		   try {
			   if(!db.isClosed()){
				   	db.close();
			   }
		   } 
		   catch (SQLException e) {
			Log.e("DBAdapter", "Erro ao fechar conex�o> " + e.getMessage());
		   }
		}
	}
		

	
	public int getDatabaseVersion() {
		return 0;//DBHelper.databaseVersion;
	}
	
	
}