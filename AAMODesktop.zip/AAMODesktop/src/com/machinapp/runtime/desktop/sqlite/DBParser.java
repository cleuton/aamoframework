package com.machinapp.runtime.desktop.sqlite;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


import com.machinapp.runtime.desktop.AamoException;
import com.machinapp.runtime.desktop.sqlite.model.Column;
import com.machinapp.runtime.desktop.sqlite.model.Database;
import com.machinapp.runtime.desktop.sqlite.model.Table;
import com.machinapp.runtime.desktop.util.Context;
import com.machinapp.runtime.desktop.util.Log;

public class DBParser {
	
	private Context ctx;
	private String currentStringValue;
	private String currentElementName;
	private int currentMacro;
	
	private com.machinapp.runtime.desktop.sqlite.model.Table tableElement;
	private com.machinapp.runtime.desktop.sqlite.model.Column column;
	private com.machinapp.runtime.desktop.sqlite.model.Database db;
	
	private static final int  MACRO_BD = 1;		//aamo-bd
	private static final int  MACRO_ELEMENT = 2; //table
	private static final int  MACRO_COLUMNS = 3; //columns
	private static final int  MACRO_COLUMN = 4;  //column	
	
	private static final String  PATH_XML = "app/bd/bd.xml";
	
	private List<Table> tables = new ArrayList<Table>();
	private List<Column> columns;
	
	public DBParser (Context ctx){
		 this.ctx = ctx;
	}
	
	public Database readXMLDatabase(Context ctx) throws AamoException {
		
		InputStream xml;
		Database db = null;
		try {
		
			db = new Database();
			
			File fXmlFile = new File(ctx.getDbPath() + "/bd.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = (Document) dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			Element root = doc.getDocumentElement();
			db.setName(root.getElementsByTagName("name").item(0).getTextContent());
			db.setTablesList(new ArrayList<Table>());
			NodeList tabelas = doc.getElementsByTagName("table");
			for (int x = 0; x < tabelas.getLength(); x++) {
				Node nNode = tabelas.item(x);
				Element eElement = (Element) nNode;
				tableElement = new Table();
				tableElement.setName(eElement.getElementsByTagName("name").item(0).getTextContent());
				tableElement.setColumnsList(new ArrayList<Column>());
				NodeList colunas = eElement.getElementsByTagName("column");
				for (int i = 0; i < colunas.getLength(); i++) {
					column = new Column();
					Node colNode = colunas.item(i);
					Element colElement = (Element) colNode;
					column.setName(colElement.getElementsByTagName("name").item(0).getTextContent());
					column.setType(colElement.getElementsByTagName("type").item(0).getTextContent());
					if (colElement.getElementsByTagName("primarykey").getLength() > 0) {
						column.setPrimaryKey(true);
					}
					if (colElement.getElementsByTagName("notnull").getLength() > 0) {
						column.setNotNull(true);
					}
					tableElement.getColumnsList().add(column);
				}
				db.getTablesList().add(tableElement);
			}
			
			
		}
		catch(Exception ex) {
			Log.e("DBHelper", "Erro ao analisar xml do banco> " + ex.getMessage());
		}
		
		return db;
	}
	
	
}
