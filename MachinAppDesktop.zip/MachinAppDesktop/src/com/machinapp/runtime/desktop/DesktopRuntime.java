package com.machinapp.runtime.desktop;

import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;

import com.machinapp.runtime.desktop.util.Context;

public class DesktopRuntime {
	public static void start(String appPath) {
		File mainPath = new File(appPath);
		
		if (!mainPath.exists()) {
			JFileChooser chooser = new JFileChooser();
			chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		    int returnVal = chooser.showOpenDialog(null);
		    
		    if(!(returnVal == JFileChooser.APPROVE_OPTION)) {
		    	return;
		    }
		    mainPath = chooser.getSelectedFile();
		}
		final File filePath = mainPath;
		SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	AamoDroidActivity screen = new AamoDroidActivity(getContext(filePath));
        		screen.context.setAppTitle("Test MachinApp");
            }
        });
		
		
	}
	
	public static void main (String [] args) {
		String path = "";
		if (args.length > 0 && args[0] != null) {
			path = args[0];
		}
		start(path);
	}
	
	private static Context getContext(File mainPath) {
		Context context = new Context();
		context.setAppPath(mainPath);
		File dbPath = new File(mainPath.getPath() + "/bd");
		context.setDbPath(dbPath);
		
		return context;
	}
}
