package com.machinapp.runtime.desktop;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.Stack;

import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.keplerproject.luajava.LuaObject;
import org.keplerproject.luajava.LuaState;
import org.keplerproject.luajava.LuaStateFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;


import chrriis.dj.nativeswing.swtimpl.NativeInterface;
import chrriis.dj.nativeswing.swtimpl.components.JWebBrowser;

import com.machinapp.runtime.desktop.util.Context;
import com.machinapp.runtime.desktop.util.Log;



public class AamoDroidActivity extends JFrame implements ActionListener, KeyListener {
	
	public static final double VERSION = 1.0;
	public static final int MACRO_UI = 1;
	public static final int  MACRO_ELEMENT = 2;
	public static final int  MACRO_MENU = 3;
	public static final String AAMOL10N = "aamol10n";
	public static final String AAMOL10N_MARKER = "l10n::";
	public static final String GLOBAL_LISTBOX_INDEX = "aamo::selectedIndex";
	public static final String GLOBAL_LISTBOX_TEXT = "aamo::selectedText";
	public static final String GLOBAL_MENU_INDEX = "aamo::selectedMenuIndex";
	public static final String GLOBAL_MENU_TEXT = "aamo::selectedMenuText";
	
	protected List<DynaView> dynaViews;
	
	protected ScreenData screenData;

    String currentStringValue;
    String currentElementName;
    int currentMacro;
    DynaView currentElement;
    protected JPanel dvLayout;
    //protected ViewFlipper baseLayout;
    protected JPanel baseLayout = new JPanel(new CardLayout());
    protected static AamoDroidActivity selfRef;
    public Context context;
    
    // Screen and controls stacks
    
    protected Stack<ScreenData> screenStack;
    protected Stack<List<DynaView>> controlsStack;
    
    // Lua
    
    protected LuaState L;
    
    // L10N
    
    public ResourceBundle res;
    
    // Exec scripts
    
    public boolean execOnLeaveOnBack = true;
    
    // Global params
    
    public List<GlobalParameter> globalParameters = new ArrayList<GlobalParameter>();
    
    // Constants
    
    public String listaLibs = "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_getTextField\")\r\n" 
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_setTextField\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_showMessage\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_loadScreen\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_exitScreen\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_getCurrentScreenId\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_log\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_getLabelText\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_setLabelText\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_getCheckBox\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_setCheckBox\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_getError\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_showScreen\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_getLocalizedText\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_setGlobalParameter\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_getGlobalParameter\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_addListBoxOption\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_clearListBox\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_showMenu\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_navigateTo\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_setPicture\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_query\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_execSQL\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_next\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_closeCursor\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_eof\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_openDatabase\")\r\n"
			+ "luajava.loadLib(\"com.machinapp.runtime.desktop.AamoLuaLibrary\", \"m_closeDatabase\")\r\n";	
    
    
    public AamoDroidActivity(Context context) {
    	this.context = context;
    	this.selfRef = this;
    	setupSwing();
    	this.addKeyListener(this);
    	screenStack = new Stack<ScreenData>();
        controlsStack = new Stack<List<DynaView>>();
        
        // Setup library
        
        AamoLuaLibrary.selfRef = this;
		
		// Load xml for the base ui
        
        try {
			loadUI(1);
		} catch (AamoException e) {
			e.printStackTrace();
		}
        
        // Format it's subviews
        
        formatSubviews();
        
        
        this.setVisible(true);
       
    }
	
    
    protected void setupSwing() {
    	this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    	this.addWindowListener(new WindowListener() {
			@Override
			public void windowActivated(WindowEvent arg0) {
			}
			@Override
			public void windowClosed(WindowEvent arg0) {
			}
			@Override
			public void windowClosing(WindowEvent e) {
				selfRef.setVisible(false);
				selfRef.dispose();
			}
			@Override
			public void windowDeactivated(WindowEvent arg0) {
			}
			@Override
			public void windowDeiconified(WindowEvent arg0) {
			}
			@Override
			public void windowIconified(WindowEvent arg0) {
			}
			@Override
			public void windowOpened(WindowEvent arg0) {
			}
		});
    	this.setSize(this.context.getScreenWidth(), this.context.getScreenHeight());
    	this.setResizable(false);
    	this.setTitle(this.context.getAppTitle());
    	Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		int w = this.getSize().width;
		int h = this.getSize().height;
		int x = (dim.width-w)/2;
		int y = (dim.height-h)/2;
		this.setLocation(x, y);
		this.getContentPane().add(baseLayout);
		//this.setScreenTop(y);
		//this.setScreenLeft(x);
		
		    	
    }
    

	protected void formatSubviews() {
		dvLayout = new JPanel(null);
        dvLayout.setBackground(screenData.bgColor);
		
		int screenHeight = this.context.getScreenHeight();
		int screenWidth = this.context.getScreenWidth();
		
	    for(DynaView dv : dynaViews) {
	    	
	        int height = (int) Math.round((dv.percentHeight / 100.00f) * (float)screenHeight);
	        int width =  (int) Math.round((dv.percentWidth / 100.00f) * (float)screenWidth);
	        int top = (int) Math.round((dv.percentTop / 100.00f) * (float)screenHeight);
	        int left = (int) Math.round((dv.percentLeft / 100.00f) * (float)screenWidth);
	        
	        switch (dv.type) {
	            case TEXTBOX: 
	                // Textbox
	            	JTextField tv = new JTextField();
	            	tv.setBounds(left, top, width, height);
	            	dvLayout.add(tv);
	                dv.view = tv;
	                tv.setName(dv.id + "");  
	                if (dv.text != null) {
	                	tv.setText(checkL10N(dv.text));
	                }
	                break;
	            
	            case LABEL: {
	                // Label
	            	JLabel lv = new JLabel();
	            	lv.setHorizontalAlignment(SwingConstants.CENTER);
	            	lv.setBounds(left, top, width, height);
	            	dvLayout.add(lv);
	                dv.view = lv;
	                lv.setName(dv.id + "");
	                if (dv.text != null) {
	                    lv.setText(checkL10N(dv.text));
	                }
	                break;
	            }
	            case BUTTON: {
	                // Button
	            	JButton bv = new JButton();
	            	bv.setBounds(left, top, width, height);
	            	dvLayout.add(bv);
	                dv.view = bv;
	                bv.setName(dv.id + "");
	                bv.addActionListener(this);
	                bv.setText(checkL10N(dv.text));

	                break;
	            }
	            case CHECKBOX: {
	                // Checkbox
	            	JCheckBox sv = new JCheckBox();
	            	sv.setBounds(left, top, width, height);
	            	dvLayout.add(sv);
	                dv.view = sv;
	                sv.setName(dv.id + "");
	                sv.setSelected(dv.checked);
	                if (dv.onChangeScript != null && dv.onChangeScript.length() > 0) {
	                	final String codigo = dv.onChangeScript;
	                	sv.addItemListener(
	                				new ItemListener() {

										@Override
										public void itemStateChanged(
												ItemEvent arg0) {
											execLua(codigo);
											
										}
	                					
	                				}
	                			);
	                }
	                break;
	            }
	            case LISTBOX: {
	            	JList lv = new JList();
	            	JScrollPane scrollPane = new JScrollPane(lv);
	            	scrollPane.setBounds(left, top, width, height);
	            	dvLayout.add(scrollPane);
	                dv.view = lv;
	                lv.setName(dv.id + "");
	                dv.listElements = new ArrayList<String>();
	                lv.setListData(dv.listElements.toArray());
	                if (dv.onElementSelected != null && dv.onElementSelected.length() > 0) {
	                	final String codigo = dv.onElementSelected;
	                	
	                	lv.addListSelectionListener(
	                			new ListSelectionListener() {

									@Override
									public void valueChanged(
											ListSelectionEvent arg0) {
										// Colocar selected element em Global Parameters
										int position = arg0.getFirstIndex();
										JList lista = (JList) arg0.getSource();
										GlobalParameter gp = new GlobalParameter();
										gp.setName(GLOBAL_LISTBOX_INDEX);
										if (globalParameters.contains(gp)) {
											gp = globalParameters.get(globalParameters.indexOf(gp));
											gp.setJavaObject(new Integer(position));
										}
										else {
											gp.setJavaObject(new Integer(position));
											globalParameters.add(gp);
										}
										gp = new GlobalParameter();
										gp.setName(GLOBAL_LISTBOX_TEXT);
										if (globalParameters.contains(gp)) {
											gp = globalParameters.get(globalParameters.indexOf(gp));
											gp.setJavaObject(lista.getSelectedValue());
										}
										else {
											gp.setJavaObject(lista.getSelectedValue());
											globalParameters.add(gp);
										}
										execLua(codigo);
										
									}
	                				
	                			}
	                			);
	                	
	                }
	            	break;
	            }
	            
	            case WEBBOX: {
	            	try {
	            		NativeInterface.initialize();
	            		NativeInterface.open();
		            	final JWebBrowser wv = new JWebBrowser();
		            	wv.setBounds(left, top, width, height);
		            	dvLayout.add(wv);
		                dv.view = wv;
		                wv.setName(dv.id + "");
		                wv.setJavascriptEnabled(true);
		                if (dv.url != null && dv.url.length() > 0) {
		                	final String wurl = dv.url;
		                	//SwingUtilities.invokeLater(new Runnable() {
								//@Override
								//public void run() {
									wv.navigate(checkL10N(wurl));
								//}
		                	//});
		                	
		                }
		              
	            	}
	            	catch (Exception exx) {
	            		Log.e("WEBBOX", exx.getMessage());
	            	}
	            	
	            	break;
	            }
	            
	            case IMAGEBOX: {
	            	final JLabel iv = new JLabel();
	            	iv.setBounds(left, top, width, height);
	            	dvLayout.add(iv);
	                dv.view = iv;
	                iv.setName(dv.id + "");
	                iv.addMouseListener(new MouseAdapter() {
	                    @Override
	                    public void mouseClicked(MouseEvent e) {
							for (DynaView dv : dynaViews) {
								Integer idImagem = Integer.parseInt(iv.getName());
								if (idImagem.equals(new Integer(dv.id))) {
									if (dv.onClickScript != null && dv.onClickScript.length() > 0) {
										execLua(dv.onClickScript);
									}
									break;
								}
							}
	                    }
	                }
	                );
	                BufferedImage myPicture = null;
	                if (dv.picture != null && dv.picture.length() > 0) {
	                	try {
	                		String imagePath = context.getAppPath() + "/" + checkL10N(dv.picture);
	                		myPicture = ImageIO.read(new File(imagePath));
						} catch (IOException e) {
							Log.d("AAMO::Lua","Exception loading IMAGEBOX: " + e.getLocalizedMessage());
						}
	                	
	                }
	                if (!dv.stretch) {
	                	// O tamanho da imagem n�o deve ser modificado
	                	iv.setIcon(new ImageIcon(myPicture));
	                }
	                else {
	                	// � para modificar o tamanho da imagem
	                	Image newSize = myPicture.getScaledInstance(width, height, Image.SCALE_DEFAULT);
	                	iv.setIcon(new ImageIcon(newSize));
	                }
	            }
	                
	        }
	        
	    }
	    baseLayout.add(dvLayout, screenData.uiid + "");
        CardLayout cl = (CardLayout)(baseLayout.getLayout());
        cl.show(baseLayout,screenData.uiid + "");
	    screenData.dvLayout = dvLayout;
	    screenStack.push(screenData);
	    
	    // Check "onLoadScreen" event:
	    
	    if (screenData.onLoadScript != null && screenData.onLoadScript.length() > 0) {
			execLua(screenData.onLoadScript);
	    }

	}

	protected boolean loadUI(int screenId) throws AamoException {
		String uiPath = null;
		boolean resultado = true;
		try {
			dynaViews = new ArrayList<DynaView>();
			screenData = new ScreenData();
			if (screenId == 1) {
				uiPath = context.getAppPath() + "/ui.xml";
			}
			else {
				uiPath = context.getAppPath() + "/ui_" + screenId + ".xml";
			}
			
			
			File fXmlFile = new File(uiPath);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			
			InputStream is = new FileInputStream(uiPath);  
			Reader reader = new InputStreamReader(is, "UTF-8"); // look up which encoding your file should have  
			InputSource source = new InputSource(reader);  
			source.setEncoding("UTF-8");
			Document doc = dBuilder.parse(source);  
			
			
			//Document doc = (Document) dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			Element root = doc.getDocumentElement();
			
			screenData.uiid = Integer.parseInt(root.getElementsByTagName("uiid").item(0).getTextContent());
			NodeList nos = root.getElementsByTagName("title");
			if (nos != null && nos.getLength() > 0) {
				screenData.title = nos.item(0).getTextContent();
			}
			nos = root.getElementsByTagName("onLoadScript");
			if (nos != null && nos.getLength() > 0) {
				screenData.onLoadScript = nos.item(0).getTextContent();
			}
			nos = root.getElementsByTagName("onEndScript");
			if (nos != null && nos.getLength() > 0) {
				screenData.onEndScript = nos.item(0).getTextContent();
			}
			nos = root.getElementsByTagName("onLeaveScript");
			if (nos != null && nos.getLength() > 0) {
				screenData.onLeaveScript = nos.item(0).getTextContent();
			}
			nos = root.getElementsByTagName("onBackScript");
			if (nos != null && nos.getLength() > 0) {
				screenData.onBackScript = nos.item(0).getTextContent();
			}
			nos = root.getElementsByTagName("onMenuSelected");
			if (nos != null && nos.getLength() > 0) {
				screenData.onMenuSelected = nos.item(0).getTextContent();
			}
			nos = root.getElementsByTagName("backgroundColor");
			if (nos != null && nos.getLength() > 0) {
				String bgColor = nos.item(0).getTextContent();
				if (bgColor != null && bgColor.length() > 0) {
					screenData.bgColor = new Color(checkColor(bgColor));
				}
			}
			
			nos = root.getElementsByTagName("menu");
			if (nos != null && nos.getLength() > 0) {
				NodeList itensMenu = ((Element)nos.item(0)).getElementsByTagName("option");
				if (itensMenu != null && itensMenu.getLength() > 0) {
					screenData.menuOptions = new ArrayList<String>();
					for (int x = 0; x < itensMenu.getLength(); x++) {
						if (itensMenu.item(x).getTextContent() != null) {
							screenData.menuOptions.add(itensMenu.item(x).getTextContent());
						}
					}
				}
			}
			
			NodeList elementos = root.getElementsByTagName("element");
			DynaView elemento = null;
			if (elementos != null & elementos.getLength() > 0) {
				for (int x = 0; x < elementos.getLength(); x++) {
					elemento = new DynaView();
					Element el = (Element) elementos.item(x);
					dynaViews.add(elemento);
					nos = el.getElementsByTagName("id");
					if (nos != null & nos.getLength() > 0) {
						elemento.id = Integer.parseInt(nos.item(0).getTextContent());
					}
					nos = el.getElementsByTagName("type");
					if (nos != null & nos.getLength() > 0) {
						elemento.type = DynaView.CONTROL_TYPE.values()[Integer.parseInt(nos.item(0).getTextContent())];
					}
					nos = el.getElementsByTagName("percentTop");
					if (nos != null & nos.getLength() > 0) {
						elemento.percentTop = Float.parseFloat(nos.item(0).getTextContent());
					}
					nos = el.getElementsByTagName("percentLeft");
					if (nos != null & nos.getLength() > 0) {
						elemento.percentLeft = Float.parseFloat(nos.item(0).getTextContent());
					}
					nos = el.getElementsByTagName("percentWidth");
					if (nos != null & nos.getLength() > 0) {
						elemento.percentWidth = Float.parseFloat(nos.item(0).getTextContent());
					}
					nos = el.getElementsByTagName("percentHeight");
					if (nos != null & nos.getLength() > 0) {
						elemento.percentHeight = Float.parseFloat(nos.item(0).getTextContent());
					}
					nos = el.getElementsByTagName("text");
					if (nos != null & nos.getLength() > 0) {
						elemento.text = nos.item(0).getTextContent();
					}
					nos = el.getElementsByTagName("onClickScript");
					if (nos != null & nos.getLength() > 0) {
						elemento.onClickScript = nos.item(0).getTextContent();
					}
					nos = el.getElementsByTagName("checked");
					if (nos != null & nos.getLength() > 0) {
						elemento.checked = Integer.parseInt(nos.item(0).getTextContent()) == 1;
					}
					nos = el.getElementsByTagName("onChangeScript");
					if (nos != null & nos.getLength() > 0) {
						elemento.onChangeScript = nos.item(0).getTextContent();
					}
					nos = el.getElementsByTagName("onElementSelected");
					if (nos != null & nos.getLength() > 0) {
						elemento.onElementSelected = nos.item(0).getTextContent();
					}
					nos = el.getElementsByTagName("url");
					if (nos != null & nos.getLength() > 0) {
						elemento.url = nos.item(0).getTextContent();
					}
					nos = el.getElementsByTagName("picture");
					if (nos != null & nos.getLength() > 0) {
						elemento.picture = nos.item(0).getTextContent();
					}
					nos = el.getElementsByTagName("stretch");
					if (nos != null & nos.getLength() > 0) {
						elemento.stretch = Integer.parseInt(nos.item(0).getTextContent()) == 1;
					}
				}
			}
			
			this.setJMenuBar(null);
			if (screenData.menuOptions != null && screenData.menuOptions.size() > 0) {
	        	setupMenu();
	        }			
			controlsStack.push(dynaViews);
		}
		catch (Exception ex) {
			Log.d("XML", "Exception: " + ex);
			resultado = false;
			throw new AamoException (ex);
		}
		return resultado;		
	
	}
    
	private boolean getStretch(String tagstretch) {
		boolean stretch = false;
		try {
			int stvalue = Integer.parseInt(tagstretch);
			stretch = (stvalue == 1) ? true : false;
		}
		catch (NumberFormatException nfe) {
			
		}
		return stretch;
	}

	private int checkColor(String htmlCode) {
		// #FFCCDD
		// 0123456
		int color = Color.BLACK.getRGB();
		if (htmlCode != null &&
				htmlCode.length() == 7 &&
				htmlCode.charAt(0) == '#') {
			try {
				int cRed   = Integer.parseInt(htmlCode.substring(1, 3),16);
				int cGreen = Integer.parseInt(htmlCode.substring(3, 5),16);
				int cBlue  = Integer.parseInt(htmlCode.substring(5),16);
				color = (new Color(cRed, cGreen, cBlue)).getRGB();
			}
			catch (NumberFormatException nfe) {
				
			}
		}
		return color;
	}

	protected void showAlertMessage(String msg) {
		
		JOptionPane.showMessageDialog(this, msg);
	}


	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() instanceof JMenuItem) {
			menuSelecionado((JMenuItem) e.getSource());
		}
		else {
			String name = "";
			for (DynaView dv : dynaViews) {
				JComponent controle = (JComponent) e.getSource();
				Integer idControle = Integer.parseInt(controle.getName());
				if (idControle.equals(new Integer(dv.id))) {
					name = dv.onClickScript;
					execLua(name);
					break;
				}
			}			
		}

	}
	
	protected void execLua (String script) {
		
		try {
			if (L == null) {
				L = LuaStateFactory.newLuaState();
				L.openLibs();
				L.setTop(0);
			}
			
			String codigo = listaLibs;
			
			if (script.indexOf("lua::") < 0) {
				InputStream is = new FileInputStream(context.getAppPath() + "/" + script + ".lua");
				byte[] bytes = readAll(is);
				codigo += (new String(bytes));
			}
			else {
				codigo += script.substring(5);  // after "lua::"
				
			}
			
			
			L.LloadString(codigo);
			int ok = L.pcall(0, 0, 0);
			if (ok == 0) {
				return;
			}
			else {
				String msg = L.toString(-1);
				Log.d("AAMO::Lua",msg);
			}

			
		} catch (Exception e) {
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			e.printStackTrace(new PrintStream(os));
			L.pushString("Cannot load module "+script+":\n"+os.toString());
			
		}
	}
	
	public ResourceBundle getBundle() {
		ResourceBundle res = null;
		String userLanguage = Locale.getDefault().getLanguage();
		String userCountry  = (Locale.getDefault().getCountry() == null) ? "" : "_" + Locale.getDefault().getCountry();
		
		String preferredName = AAMOL10N + "_" + userLanguage + userCountry + ".properties";
		int index = 0;
		String names[] = {
			preferredName,
			AAMOL10N + "_" + userLanguage + ".properties",
			AAMOL10N + ".properties"
		};
		boolean loading = true;
		do {
			try {
				InputStream is = new FileInputStream(context.getAppPath() + "/" + names[index]);
				res = new PropertyResourceBundle(is);
				loading = false;
			} catch (Exception e) {
				index++;
				if (index > 2) {
					AamoLuaLibrary.errorCode = 100;
					loading = false;
				}
			}
			
		} while (loading);
		return res;
	}

	
	// This solution, to read scripts from the Assets folder, came from Michal Kottman's project "Androlua" (https://github.com/mkottman/AndroLua)
	protected static byte[] readAll(InputStream input) throws Exception {
		ByteArrayOutputStream output = new ByteArrayOutputStream(4096);
		byte[] buffer = new byte[4096];
		int n = 0;
		while (-1 != (n = input.read(buffer))) {
			output.write(buffer, 0, n);
		}
		return output.toByteArray();
	}

	public String checkL10N(String texto) {
		String saida = texto;
		int pos = -1;
		if ((pos = texto.indexOf(AAMOL10N_MARKER)) >= 0) {
			saida = getL10N(texto.substring(pos + AAMOL10N_MARKER.length()));
		}
		return saida;
	}

	public String getL10N(String substring) {
		String result = null;
		if (res == null) {
			res = getBundle();
		}
		try {
			result = res.getString(substring);	
		}
		catch (MissingResourceException mre) {
			result = "??????";
		}
		
		return res.getString(substring);
	}

	public void execOnLeave() {
		// Check if the screen has an "onLeaveScript"
        
        if (execOnLeaveOnBack  && 
        		screenData.onLeaveScript != null && screenData.onLeaveScript.length() > 0) {
            execLua(screenData.onLeaveScript);
        }
		
	}

	public void setupMenu() {
		screenData.menu = new JPopupMenu();
		for (String texto : screenData.menuOptions) {
			JMenuItem item = new JMenuItem(this.checkL10N(texto));
			item.addActionListener(this);
			screenData.menu.add(item);
		}
		
	}


	public void menuSelecionado(JMenuItem item) {
		int posicao = screenData.menuOptions.indexOf(item.getText());
		GlobalParameter gp = new GlobalParameter();
		gp.setName(GLOBAL_MENU_INDEX);
		if (globalParameters.contains(gp)) {
			gp = globalParameters.get(globalParameters.indexOf(gp));
			gp.setJavaObject(new Integer(posicao));
		}
		else {
			gp.setJavaObject(new Integer(posicao));
			globalParameters.add(gp);
		}
		gp = new GlobalParameter();
		gp.setName(GLOBAL_MENU_TEXT);
		if (globalParameters.contains(gp)) {
			gp = globalParameters.get(globalParameters.indexOf(gp));
			gp.setJavaObject(this.checkL10N(item.getText()));
		}
		else {
			gp.setJavaObject(this.checkL10N(item.getText()));
			globalParameters.add(gp);
		}
		if (screenData.onMenuSelected != null && screenData.onMenuSelected.length() > 0) {
			execLua(screenData.onMenuSelected);
		}
	}



	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void keyTyped(KeyEvent arg0) {
		if (arg0.getKeyCode() == KeyEvent.VK_ESCAPE) {
			if (screenStack.size() > 1) {
				AamoLuaLibrary.exitScreen();
			}

		}
		
	}
	

	
}