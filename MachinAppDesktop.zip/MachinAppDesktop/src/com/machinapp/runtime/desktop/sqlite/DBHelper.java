package com.machinapp.runtime.desktop.sqlite;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.machinapp.runtime.desktop.sqlite.model.Column;
import com.machinapp.runtime.desktop.sqlite.model.Database;
import com.machinapp.runtime.desktop.sqlite.model.Table;
import com.machinapp.runtime.desktop.util.Log;
import com.machinapp.runtime.desktop.util.Context;


public class DBHelper  {
	
	    private static String databaseName; 
	    public  int databaseVersion; 		
	    private String tableName;		    
	    private Context context;
	    Database database;
	    static String[] colunas;
	    private static final String TAG = "AAMO";
	    private Connection db;
	    
	    /*
		public DBHelper(Context context) {
			super(context, databaseName, null, databaseVersion);
			this.context = context;
		}*/
		
		public DBHelper(Context context, Database database) {
			
			this.context = context;
			this.database = database;
		}
		
		private Connection createDatabase() {
			 Log.d(TAG, "Creating tables ");
			 StringBuilder sb = new StringBuilder();
			 db = null;
			 try{
				 Class.forName("org.sqlite.JDBC");
				 String dbname = (database.getName().indexOf(".db") < 0) ? database.getName() + ".db" : database.getName();
				 db = DriverManager.getConnection("jdbc:sqlite:" + context.getDbPath() + "/" + dbname);
				 List<Table> tables = database.getTablesList();
				 
				 for (Table table : tables) {
					
					 String name   = table.getName();
					 sb.append("CREATE TABLE ");
					 sb.append(name);
					 sb.append ("( ");
					 
					 List<Column> columns = table.getColumnsList();
					 String separador = ",";
					 int numberOfColumns = columns.size();
					 int count = 1;
					 for (Column colunas : columns) {
						 String columnName = colunas.getName();
						 sb.append(columnName + " ");
						 String type = colunas.getType() ;
						 sb.append(type + " ");
						 //PK
						 if (colunas.isPrimaryKey()){
							 sb.append(" PRIMARY KEY ");
						 }	
						 //not null
						 if (colunas.isNotNull()){
							 sb.append(" Not Null ");
						 }else {
							 sb.append(" Null ");
						 }
						 //comma ","
						 if (count < numberOfColumns){
							 sb.append(separador);
						 }
						 count ++;
					 }

					 sb.append (" )");
					 Statement stmt = db.createStatement();
					 stmt.executeUpdate(sb.toString());

				 }
				 
			     
			 }catch(SQLException e)
			 {
				 Log.e("DBHelper", "Erro ao criar database> " + e.getMessage());
			 } catch (ClassNotFoundException e) {
				 Log.e("DBHelper", "Erro ao criar database> " + e.getMessage());
			}
			 
			 return db;
		}
		
		

		public Connection getWritableDatabase() {
			String dbPath = context.getDatabasePath(this.database.getName());
			db = null;
			if (dbPath == null) {
				createDatabase();

			}
			else {
				try {
					Class.forName("org.sqlite.JDBC");
					db = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
				} catch (ClassNotFoundException e) {
					Log.e("DBHelper", "Erro ao obter a classe do driver> " + e.getMessage());
				} catch (SQLException e) {
					Log.e("DBHelper", "Erro ao abrir conex�o com o banco> " + e.getMessage());
				}
			}

			return db;
		}
}
