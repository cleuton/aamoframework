package com.machinapp.runtime.desktop;

import java.awt.Color;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;


//import android.widget.RelativeLayout; -> JComponent


public class ScreenData {
	public int uiid;
    public String title;
    public String onLoadScript;
    public String onEndScript; 
    public String onLeaveScript;
    public String onBackScript;
    public JPanel dvLayout;
    public List<String> menuOptions;
    public JPopupMenu menu;
    public String onMenuSelected;
    public Color bgColor;
}
