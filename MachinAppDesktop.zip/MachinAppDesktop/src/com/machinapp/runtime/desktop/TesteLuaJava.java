package com.machinapp.runtime.desktop;

import org.keplerproject.luajava.LuaState;
import org.keplerproject.luajava.LuaStateFactory;

public class TesteLuaJava {
	
	/*
	 * Colocar no VM arguments:
	 * -Djava.library.path=C:/projetos/JNITest/WSTEST1/TestLua/libs/
	 */
	
	public static void main(String [] args) {
		
		String codigo = "sys = luajava.bindClass(\"java.lang.System\")\r\nprint ( sys:currentTimeMillis() )";
		
		LuaState L = LuaStateFactory.newLuaState();
		L.openLibs();
		L.LloadString(codigo);
		int ok = L.pcall(0, 0, 0);
		if (ok == 0) {
			return;
		}
	}
}
