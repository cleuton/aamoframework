package com.machinapp.runtime.desktop;

import java.awt.CardLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.JComponent;
import org.keplerproject.luajava.JavaFunction;
import org.keplerproject.luajava.LuaException;
import org.keplerproject.luajava.LuaObject;
import org.keplerproject.luajava.LuaState;

import chrriis.dj.nativeswing.swtimpl.components.JWebBrowser;

import com.machinapp.runtime.desktop.sqlite.DBAdapter;
import com.machinapp.runtime.desktop.util.Log;


public class AamoLuaLibrary {
	
	public static AamoDroidActivity selfRef;
	public static int errorCode = 0;
	private static ResultSet cursorMaster;
	private static Map<String, ResultSet> cursorMap = new HashMap<String, ResultSet>();
	
	//errors LUA 
	protected enum Errors {
	    LUA_10(10), 	// parametro faltando 
	    LUA_11(11), 	// Arquivo nÃ£o encontrado
	    LUA_12(12), 	// Valor igual a nulo
	    LUA_13(13),
	    LUA_14(14), 
	    LUA_15(15),
	    LUA_20(20),		// erro no open database
	    LUA_21(21),     // erro na query - retorna nil 
	    LUA_22(22),     // erro no ExecSQL - comando invalido
	    LUA_100(100); 
	    
	    int errorCode;
	    
	    Errors (int error){
	    	errorCode = error;
	    }
	    
	    int getErrorCode(){
	    	return errorCode;
	    }
	}
	
	//**** Funcoes a serem invocadas pelo codigo Lua
	public static int m_getTextField(LuaState L) throws LuaException {
	  L.newTable();
	  L.pushValue(-1);
	  L.setGlobal("aamo");
	  L.pushString("getTextField");
	  L.pushJavaFunction(new JavaFunction(L) {
	    public int execute() throws LuaException {  
	      if (L.getTop() > 1) {
	    	  LuaObject d = getParam(2);
	    	  if (d == null){
	    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode(); 
	    		  return 0;
	    	  }
	    	  else
	    	  {	  
	    		  //L.pushString(getTextBox(d));
	    		  String txt = getTextBox(d);
	    		  if (txt == null){
		    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
		    		  return 0;
		    	  }else{
		    		  L.pushString(txt);  
		    	  }
	    	  }	  
	      }
	      else 
	      {
	    	  AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
	      }
	      
	      return 1;
	    }
	  });
	  L.setTable(-3);
	  return 1;
	}

	private static String getTextBox(LuaObject d) {
		double nd = d.getNumber();
		String texto = null;
		for (DynaView dv : selfRef.dynaViews) {
			if (dv.id == nd) {
				if (dv.type == DynaView.CONTROL_TYPE.TEXTBOX) { // Ã© um textbox
					texto = ((JTextField) dv.view).getText();
					break;
				}
				else {
					break;
				}
				
			}
		}
		return texto;
	}
	
	public static int m_showMessage(LuaState L) throws LuaException {
	  L.newTable();
	  L.pushValue(-1);
	  L.getGlobal("aamo");
	  L.pushString("showMessage");
	  L.pushJavaFunction(new JavaFunction(L) {
	    public int execute() throws LuaException {  
	      if (L.getTop() > 1) {
	    	  LuaObject msg = getParam(2);
	    	  if (msg == null){
	    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
	    		  return 0;
	    	  }else {
	    		  showMessageBox(msg);  
	    	  }
	      }
	      else 
	      {
	    	  AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
	      }
	      return 0;
	    }
	  }); 
	  L.setTable(-3);
	  return 1;
	}
	
	public static int m_loadScreen(LuaState L) throws LuaException {
	  L.newTable();
	  L.pushValue(-1);
	  L.getGlobal("aamo");
	  L.pushString("loadScreen");
	  L.pushJavaFunction(new JavaFunction(L) {
	    public int execute() throws LuaException {  
	      if (L.getTop() > 1) {
	    	  LuaObject tela = getParam(2);
	    	  try{
	    	  	  loadScreen(tela);
	    	   }catch(AamoException ae){
	      		  AamoLuaLibrary.errorCode = 11; // arquivo nÃ£o encontrado
	      	   } 	   
	    	  
	      }else {
	    	  AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
	      }
	      return 0;
	    }
	  });
	  L.setTable(-3);
	  return 1;
	}
	
	protected static void loadScreen(LuaObject tela)throws AamoException {
		int ntela = (int) tela.getNumber();
		selfRef.execOnLeave();
		selfRef.loadUI(ntela);
		selfRef.formatSubviews();
	}
	
	protected static void showMessageBox(LuaObject msg) {
		selfRef.showAlertMessage(msg.toString());
		
	}
	
	protected static void exitScreen() {
		if (selfRef.screenStack.size() > 1) {
			// tem algo na pilha, vamos voltar
			
			// Check for "onEndScript"
			
			if (selfRef.screenData.onEndScript != null && selfRef.screenData.onEndScript.length() > 0) {
				selfRef.execLua(selfRef.screenData.onEndScript);
			}
			
			selfRef.screenData = selfRef.screenStack.pop(); // remove the current screen
			selfRef.screenData = selfRef.screenStack.peek(); // get the previous screen without removing it
			CardLayout cl = (CardLayout)(selfRef.baseLayout.getLayout());
			cl.show(selfRef.baseLayout, selfRef.screenData.uiid + "");
			cl.removeLayoutComponent(selfRef.dvLayout);
			selfRef.dvLayout = selfRef.screenData.dvLayout;
			selfRef.dynaViews = selfRef.controlsStack.pop();  // remove current controls
			selfRef.dynaViews = selfRef.controlsStack.peek(); // get the previous controls without removing them
			// Check if the screen has an "onBackScript"
	        
	        if (selfRef.execOnLeaveOnBack  && 
	        		selfRef.screenData.onBackScript != null && selfRef.screenData.onBackScript.length() > 0) {
	            selfRef.execLua(selfRef.screenData.onBackScript);
	        }
	        
	        
			if (selfRef.screenData.menuOptions != null && selfRef.screenData.menuOptions.size() > 0) {
				selfRef.setupMenu();
	        }
		}
		else {
			System.exit(0);
		}

	}
	
	public static int m_exitScreen(LuaState L) throws LuaException {
	  L.newTable();
	  L.pushValue(-1);
	  L.getGlobal("aamo");
	  L.pushString("exitScreen");
	  L.pushJavaFunction(new JavaFunction(L) {
	    public int execute() throws LuaException {  
	      exitScreen();
	      return 0;
	    }
	  });
	  L.setTable(-3);
	  return 1;
	}
	
	public static int m_getCurrentScreenId(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("getCurrentScreenId");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
			    L.pushNumber(selfRef.screenData.uiid);
			    return 1;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	public static int m_log(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("log");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		    	if (L.getTop() > 1) {
			    	  LuaObject msg = getParam(2);
			    	  Log.d("AAMO",msg.getString());
			    }
		    	else 
			    {
			        AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
			    }
			    return 0;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	public static int m_getLabelText(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("getLabelText");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		    	if (L.getTop() > 1) {
			    	  LuaObject d = getParam(2);
			    	  if (d == null){
			    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode(); 
			    		  return 0;
			    	  }
			    	  else {
			    		  String txt = getLabel(d);
			    		  if (txt == null){
				    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
				    	  }else{
				    		  L.pushString(txt);//getLabel(d)  
				    	  }
			    	  }
			    }
		    	else 
			    {
			        AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
			    }
			    return 1;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	public static int m_setLabelText(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("setLabelText");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		    	if (L.getTop() > 1) {
			       LuaObject d = getParam(2);
			       LuaObject e = getParam(3);
			       if (d == null){
			    	   AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
			    	   return 0;
			       }
			       else if (e == null) {
			    	   AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
			    	   return 0;
			       }
			       else {
			      	   setLabel(d,e);
			       }
			      
			    }else {
		    	   AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
			    }
			    return 0;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	public static int m_setTextField(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("setTextField");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		    	if (L.getTop() > 1) {
			    	LuaObject d = getParam(2);
			    	LuaObject e = getParam(3);
			    	if (d == null){
				       AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
				       return 0;
				    }
				    else if (e == null) {
				       AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
				       return 0;
				    }
				    else {
				       setTextBox(d,e);
				    }
			    }
		    	else 
		    	{
		    		AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
			    }
			    return 0;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	private static String getLabel(LuaObject d) {
		double nd = d.getNumber();
		String texto = null;
		for (DynaView dv : selfRef.dynaViews) {
			if (dv.id == nd) {
				if (dv.type == DynaView.CONTROL_TYPE.LABEL) {
					// Ã© um label
					texto = ((JLabel) dv.view).getText();
					break;
				}
				else {
					break;
				}
			}
		}
		return texto;
	}
	
	private static void setLabel(LuaObject d, LuaObject e) {
		double nd = d.getNumber();
		for (DynaView dv : selfRef.dynaViews) {
			if (dv.id == nd) {
				((JLabel) dv.view).setText(e.getString());
			}
		}
	}
	private static void setTextBox(LuaObject d, LuaObject e) {
		double nd = d.getNumber();
		for (DynaView dv : selfRef.dynaViews) {
			if (dv.id == nd) {
				((JTextField) dv.view).setText(e.getString());
			}
		}
	}
	
	public static int m_getCheckBox(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("getCheckBox");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		    	if (L.getTop() > 1) {
		    		LuaObject d = getParam(2);
		    		if (d == null){
					   AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode(); 
					   return 0;
					}
		    		else {
		    			
			    		double nd = d.getNumber();
				  		int retorno = 0;
				  		int valor = 0;
						for (DynaView dv : selfRef.dynaViews) {
							if (dv.id == nd) {
								if (dv.type == DynaView.CONTROL_TYPE.CHECKBOX) {
									retorno = 1;
									if (((JCheckBox) dv.view).isSelected()) {
										valor = 1;
				  					}
									break;
								}
							}
						}
					
						if (retorno == 0){
				    	    AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode(); 
				    	    return 0;
				    	}
				    	else {
				    		L.pushNumber(valor);
				    	}
						return 1;
		    		}
			    }
		    	else 
		    	{
			    	AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
			    	return 0;
				}
			    
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}

	public static int m_setCheckBox(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("setCheckBox");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		    	if (L.getTop() > 1) {
			    	  LuaObject d = getParam(2);
			    	  LuaObject e = getParam(3);
			    	  
			    	  if (d == null || e == null){
					       AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
					       return 0;
					  }
					  else {
			    	  
						  double nd = d.getNumber();
						  for (DynaView dv : selfRef.dynaViews) {
							  if (dv.id == nd) {	
								((JCheckBox) dv.view).setSelected(
										(e.getNumber() > 0) ? true : false);
							  }
						  }	   
			    	  }
			    }
		    	else 
		    	{
		    	   AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
			    }
			    return 0;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	public static int m_getError(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("getError");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
			    L.pushNumber(AamoLuaLibrary.errorCode);
			    return 1;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	public static int m_showScreen(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("showScreen");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		      if (L.getTop() > 1) {
		    	  LuaObject tela = getParam(2);
		    	  try{
		    		  selfRef.execOnLeave();
		    		  selfRef.execOnLeaveOnBack = false;
		    		  // Verificar se a tela já existe na pilha
		    		  int pos = -1;
		    		  for (ScreenData sd : selfRef.screenStack) {
		    			  if (sd.uiid == tela.getNumber()) {
		    				  pos = selfRef.screenStack.indexOf(sd);
		    				  break;
		    			  }
		    		  }
		    		  if (pos < 0) {
		    			  // A tela não existe na pilha
		    			  loadScreen(tela);
		    		  }
		    		  else {
		    			  ScreenData sd = null;
		    			  do {
		    				sd = selfRef.screenData;
		    				if (sd.uiid == tela.getNumber()) {
		    					break;
		    				}
		    				AamoLuaLibrary.exitScreen();
		    			  } while (sd.uiid != tela.getNumber());
		    			  if (sd.onBackScript != null && sd.onBackScript.length() > 0) {
		    				  selfRef.execLua(sd.onBackScript);
		    			  }
		    		  }
		    	   }catch(AamoException ae){
		      		  AamoLuaLibrary.errorCode = 11; // arquivo nÃ£o encontrado
		      	   } finally {	   
		      		 selfRef.execOnLeaveOnBack = true;
		      	   }
		    	  
		      }else {
		    	  AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
		      }
		      return 0;
		    }
		  });
		  L.setTable(-3);

		return 1;

	}
	
	public static int m_getLocalizedText(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("getLocalizedText");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		      if (L.getTop() > 1) {
		    	  LuaObject d = getParam(2);
		    	  if (d == null) {
		    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode(); 
		    		  return 0;
		    	  }
		    	  else {	  
		    		  String txt = selfRef.checkL10N("l10n::" + d.getString());
		    		  if (txt == null) {
			    		  AamoLuaLibrary.errorCode = Errors.LUA_100.getErrorCode();
			    		  return 0;
			    	  }
		    		  else {
			    		  L.pushString(txt);  
			    	  }
		    	  }	  
		      }
		      else {
		    	  AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
		    	  return 0;
		      }
		      
		      return 1;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	public static int m_setGlobalParameter(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("setGlobalParameter");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		    	if (L.getTop() > 1) {
			    	  LuaObject d = getParam(2);
			    	  LuaObject e = getParam(3);
			    	  
			    	  if (d == null || e == null){
					       AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
					       return 0;
					  }
					  else {
			    	  
						  String nomeParametro = d.getString();
						  GlobalParameter gp = new GlobalParameter();
						  gp.setName(nomeParametro);
						  if (selfRef.globalParameters.contains(gp)) {
							  gp = selfRef.globalParameters.get(selfRef.globalParameters.indexOf(gp));
						  }
						  else {
							  
							  selfRef.globalParameters.add(gp);
						  }
						  gp.setObject(e);
			    	  }
			    }
		    	else 
		    	{
		    	   AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
			    }
			    return 0;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	public static int m_getGlobalParameter(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("getGlobalParameter");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		    	if (L.getTop() > 1) {
			    	  LuaObject d = getParam(2);
			    	  
			    	  if (d == null){
					       AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
					       return 0;
					  }
					  else {
			    	  
						  String nomeParametro = d.getString();
						  GlobalParameter gp = new GlobalParameter();
						  gp.setName(nomeParametro);
						  if (selfRef.globalParameters.contains(gp)) {
							  gp = selfRef.globalParameters.get(selfRef.globalParameters.indexOf(gp));
							  if (gp.getObject() == null) {
								  // É um objeto java
								  if (gp.getJavaObject() instanceof java.lang.Integer) {
									  int numero = ((Integer) gp.getJavaObject()).intValue();
									  L.pushNumber(numero);
								  }
								  else {
									  String texto = (String) gp.getJavaObject();
									  L.pushString(texto);
								  }
							  }
							  else {
								  L.pushObjectValue(gp.getObject());
							  }
							  
						  }
						  else {
							  L.pushNil();
						  }
						  return 1;
			    	  }
			    }
		    	else 
		    	{
		    	   AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
			    }
			    return 0;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	public static int m_addListBoxOption(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("addListBoxOption");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		    	if (L.getTop() > 1) {
			    	LuaObject d = getParam(2);
			    	LuaObject e = getParam(3);
			    	if (d == null){
				       AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
				       return 0;
				    }
				    else if (e == null) {
				       AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
				       return 0;
				    }
				    else {
				       setListBox(d,e);
				    }
			    }
		    	else 
		    	{
		    		AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
			    }
			    return 0;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}

	protected static void setListBox(LuaObject d, LuaObject e) {
		double nd = d.getNumber();
		for (DynaView dv : selfRef.dynaViews) {
			if (dv.id == nd && dv.type == DynaView.CONTROL_TYPE.LISTBOX) {
				dv.listElements.add(e.getString());
				JList lista = (JList) dv.view;
				lista.setListData(dv.listElements.toArray());
			}
		}
	}
	
	public static int m_clearListBox(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("clearListBox");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		    	if (L.getTop() > 1) {
			    	LuaObject d = getParam(2);
			    	if (d == null){
				       AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
				       return 0;
				    }

				    else {
				    	for (DynaView dv : selfRef.dynaViews) {
							if (dv.id == d.getNumber() && dv.type == DynaView.CONTROL_TYPE.LISTBOX) {
								dv.listElements.clear();
								JList lv = (JList) dv.view;
								lv.removeAll();
							}
						}
				    }
			    }
		    	else 
		    	{
		    		AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
			    }
			    return 0;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	//m_showMenu

	public static int m_showMenu(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("showMenu");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		      selfRef.screenData.menu.show(selfRef,0,0);
		      return 0;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	//m_navigateTo
	public static int m_navigateTo(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("navigateTo");
		  L.pushJavaFunction(new JavaFunction(L) {
			  public int execute() throws LuaException {  
			    	if (L.getTop() > 1) {
				       LuaObject d = getParam(2);
				       LuaObject e = getParam(3);
				       if (d == null){
				    	   AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
				    	   return 0;
				       }
				       else if (e == null) {
				    	   AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
				    	   return 0;
				       }
				       else {
				    	   for (DynaView dv : selfRef.dynaViews) {
								if (dv.id == d.getNumber() && dv.type == DynaView.CONTROL_TYPE.WEBBOX) {									
									JWebBrowser wv = (JWebBrowser) dv.view;
									wv.navigate(selfRef.checkL10N(e.getString()));
								}
							}
				       }
				      
				    }else {
			    	   AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
				    }
				    return 0;
			    }
			  });
		  L.setTable(-3);
		  return 1;
	}
	
	public static int m_setPicture(LuaState L) throws LuaException {
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("setPicture");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		    	if (L.getTop() > 1) {
			    	LuaObject d = getParam(2);
			    	LuaObject e = getParam(3);
			    	if (d == null){
				       AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
				       return 0;
				    }
				    else if (e == null) {
				       AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode();
				       return 0;
				    }
				    else {
				       setPicture(d,e);
				    }
			    }
		    	else 
		    	{
		    		AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
			    }
			    return 0;
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}

	protected static void setPicture(LuaObject d, LuaObject e) {
		int controle = (int) d.getNumber();
		for (DynaView dv : selfRef.dynaViews) {
			Integer dvID = Integer.parseInt(dv.view.getName());
			if (dvID.equals(new Integer(controle))) {
				JLabel iv = (JLabel) dv.view;
				BufferedImage myPicture = null;
                if (dv.picture != null && dv.picture.length() > 0) {
                	try {
                		String imagePath = selfRef.context.getAppPath() + "/" + e.getString();
                		myPicture = ImageIO.read(new File(imagePath));
					} catch (IOException ex) {
						Log.d("AAMO::Lua","Exception loading IMAGEBOX: " + ex.getLocalizedMessage());
					}
                	
                }
                if (!dv.stretch) {
                	// O tamanho da imagem n�o deve ser modificado
                	iv.setIcon(new ImageIcon(myPicture));
                }
                else {
                	// � para modificar o tamanho da imagem
                	Image newSize = myPicture.getScaledInstance(iv.getWidth(), iv.getHeight(), Image.SCALE_DEFAULT);
                	iv.setIcon(new ImageIcon(newSize));
                }
				break;
			}
		}
		
	}

public static int m_query(LuaState L) throws LuaException {
		
		  
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("query");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		      if (L.getTop() > 1) {
		    	  
		    	  LuaObject d = getParam(2);   // titulo da query
		    	  LuaObject sql = getParam(3); // sql
		    	  if (d == null) {
		    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode(); 
		    		  return 0;
		    	  }
		    	  else {
		    		  DBAdapter adapter = new DBAdapter(selfRef.context);
		    		  
		    		  List <String> args = getQueryParams(L, 4);
		    		  
		    		  ResultSet cursor = adapter.query(sql.getString(), args); 
		    		  if (cursor == null){
		    			  AamoLuaLibrary.errorCode = Errors.LUA_21.getErrorCode();
				    	  return 0; 
		    		  }
		    		  try {
			    		  //cursor.next();
			    		  cursorMaster = cursor;
			    		  cursorMap.put(d.getString(), cursor);  
			    		  
			    		  if(!cursor.isAfterLast()){  
			    			    L.newTable();
			    			    ResultSetMetaData rsmd = cursor.getMetaData();
			    			    int columnsNumber = rsmd.getColumnCount();
			    			    for(int j=1; j<=columnsNumber; j++) {
				    	        	L.pushNumber(j);
			    	                L.pushString(cursor.getString(j));
				    			    L.setTable(-3);
			    	            }
				    	   }  
				    	   
			    		   return 1;
		    		  }
		    		  catch (SQLException sqle) {
		    			  Log.e("LUA", "SQLException " + sqle.getMessage());
		    		  }

		    	  }	  
		    	  
		      }
		      else {
		    	  AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
		    	  return 0;
		      }
		      return 1;

		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	/**
	 * Retorna uma table Lua com os campos do próximo registro.
	 * @param L
	 * @return
	 * @throws LuaException
	 */
	
	public static int m_next(LuaState L) throws LuaException
	{
		     
		    L.newTable();
			L.pushValue(-1);
			L.getGlobal("aamo");
			L.pushString("next");
			L.pushJavaFunction(new JavaFunction(L) {
			   public int execute() throws LuaException {
				   if (L.getTop() > 1) {
				    	  
				    	  LuaObject d = getParam(2); // titulo da query
				    	  if (d == null) {
				    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode(); 
				    		  return 0;
				    	  }
				    	  else {
				    		  try {
					    		   cursorMaster = cursorMap.get(d.getString());  
							       if(cursorMaster.next()){  
							    		L.newTable();
							    		ResultSetMetaData rsmd = cursorMaster.getMetaData();
					    			    int columnsNumber = rsmd.getColumnCount();
							    		for(int j=1; j <= columnsNumber; j++) 
									    {
									        L.pushNumber(j);
									        L.pushString(cursorMaster.getString(j));
									        L.setTable(-3);
									    }   
								   }
							       cursorMaster = null;
				    			  
				    		  }
				    		  catch (SQLException sqle) {
				    			  Log.e("LUA", "SQLException " + sqle.getMessage());
				    		  }
				    	  } 	
				          return 1;
				   }
				   else {
				    	  AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
				    	  return 0;
				  }  
			    }
		   });
			
		   L.setTable(-3);
		   return 1;
	}
	
	/**
	 * Fecha o cursor correspondente ao nome.
	 * @param L
	 * @return
	 * @throws LuaException
	 */
	public static int m_closeCursor(LuaState L) throws LuaException
	{
		    
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("closeCursor");
		  L.pushJavaFunction(new JavaFunction(L) {
			  public int execute() throws LuaException {
				   if (L.getTop() > 1) {
				    	  
				    	  LuaObject d = getParam(2); // titulo da query
				    	  if (d == null) {
				    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode(); 
				    		  return 0;
				    	  }
				    	  else {
				    		  try {
					    		   cursorMaster = cursorMap.get(d.getString());  
							       if (cursorMaster != null ) {
							    		
								    	cursorMaster.close();
						    	    }
								    cursorMaster = null;
								    cursorMap.remove(d.getString());
				    		  }
				    		  catch (Exception sqle) {
				    			  Log.e("LUA", "SQLException " + sqle.getMessage());
				    		  }
				    	  } 	
				          return 1;
				   }
				   else {
				    	  AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
				    	  return 0;
				  }  
			    }
		   });
 		   L.setTable(-3);
		   return 1;
	}
	
	/**
	 * Retorna um boolean indicando se o último comando (query ou next) 
	 * com aquele nome, retornou EOF.
	 * @param L
	 * @return int
	 * @throws LuaException
	 */
	public static int m_eof(LuaState L) throws LuaException
	{
		    
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("eof");
		  L.pushJavaFunction(new JavaFunction(L) {
			  public int execute() throws LuaException {
				   if (L.getTop() > 1) {
				    	  
				    	  LuaObject d = getParam(2); // titulo da query
				    	  if (d == null) {
				    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode(); 
				    		  return 0;
				    	  }
				    	  else {
				    		   cursorMaster = cursorMap.get(d.getString());
				    		   try {
					    		   if(!cursorMaster.isAfterLast()){
							    		L.pushBoolean(false);
						    	    }else {
						    	    	L.pushBoolean(true);
						    	    }				    			   
				    		   }
				    		   catch (SQLException sqle) {
				    			   Log.e("LUA", "SQLException " + sqle.getMessage());
				    		   }

				    	  } 	
				          return 1;
				   }
				   else {
				   	  AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
				   	  return 0;
				  }  
			   }
		  });
		  L.setTable(-3);
		  return 1;
	 }
	
	
	public static int m_execSQL(LuaState L) throws LuaException {
				  
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("execSQL");
		  L.pushJavaFunction(new JavaFunction(L) {
		    public int execute() throws LuaException {  
		      if (L.getTop() > 1) {
		    	  LuaObject d     = getParam(2); // sql
		    	  
		    	  if (d == null) {
		    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode(); 
		    		  return 0;
		    	  }
		    	  else {
		    		  DBAdapter adapter = new DBAdapter(selfRef.context);
		    		  List <String> args = getQueryParams(L, 3); //capture the parameters 
		    		  
		    		  String  registro = null;
		    		  try {
		    			  adapter.execSQL(d.getString(), args); 
		    			  registro = "Command executed successfully.";
		    		  }catch (Exception e){
		    			  AamoLuaLibrary.errorCode = Errors.LUA_22.getErrorCode();
				    	  return 0;
		    		  }
		    		  
		    		  L.pushString(registro);
		    		  
		    		  return 1;
		    	  }	  
		      }
		      else {
		    	  AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
		    	  return 0;
		      }
		    }
		  });
		  L.setTable(-3);
		  return 1;
	}
	
	/**
	 * Create and/or open a database that will be used for reading/writing
	 * @param L
	 * @return int
	 * @throws LuaException
	 */
	public static int m_openDatabase(LuaState L) throws LuaException
	{
		    
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("openDatabase");
		  L.pushJavaFunction(new JavaFunction(L) {
			  public int execute() throws LuaException {
				   if (L.getTop() > 1) {
				    	  
				    	  LuaObject d = getParam(2); // database name
				    	  if (d == null) {
				    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode(); 
				    		  return 0;
				    	  }
				    	  else {
				    		  DBAdapter adapter = new DBAdapter(selfRef.context);
					    	  try {
					    		  adapter.openDatabase(d.getString());
					    	  }catch (Exception e){
					    		  AamoLuaLibrary.errorCode = Errors.LUA_20.getErrorCode();
							   	  return 0;
					    	  }
				    	  } 	
				          return 1;
				   }
				   else {
				   	  AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
				   	  return 0;
				  }  
			   }
		  });
		  L.setTable(-3);
		  return 1;
	 }
	
	private static List<String> getQueryParams(LuaState L, int position) throws LuaException 
	{
		  List <String> args = new ArrayList<String>();
		  
		  for (int i=position; i <= L.getTop(); i++) {
			  LuaObject param  = L.getLuaObject(i);
			  
	  		  if (param.isNumber()) 
	  		  {	  
	  			  String pk = Double.toString(param.getNumber());
		    		  int idConverted = 0;
	  			  if (pk == null || pk.equals("0.0")){
		    			  args.add(null);
		    		  }
		    		  else {
		    			  idConverted = (int) param.getNumber();
		    			  args.add(Integer.toString(idConverted));
		    		  }
	  		  }else {
	  			  args.add(param.getString());
	  		  }
		  }
		  
		  return args;
	}
	
	/**
	 * clode database 
	 * @param L
	 * @return int
	 * @throws LuaException
	 */
	public static int m_closeDatabase(LuaState L) throws LuaException
	{
		    
		  L.newTable();
		  L.pushValue(-1);
		  L.getGlobal("aamo");
		  L.pushString("closeDatabase");
		  L.pushJavaFunction(new JavaFunction(L) {
			  public int execute() throws LuaException {
				   if (L.getTop() > 1) {
				    	  
				    	  LuaObject d = getParam(2); // database name
				    	  if (d == null) {
				    		  AamoLuaLibrary.errorCode = Errors.LUA_12.getErrorCode(); 
				    		  return 0;
				    	  }
				    	  else {
				    		  DBAdapter adapter = new DBAdapter(selfRef.context);
					    	  adapter.closeDatabase(d.getString()); 
				    	  } 	
				          return 1;
				   }
				   else {
				   	  AamoLuaLibrary.errorCode = Errors.LUA_10.getErrorCode();
				   	  return 0;
				  }  
			   }
		  });
		  L.setTable(-3);
		  return 1;
	 }
}
	

