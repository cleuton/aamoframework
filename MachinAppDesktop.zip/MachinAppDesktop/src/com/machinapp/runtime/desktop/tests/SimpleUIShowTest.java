package com.machinapp.runtime.desktop.tests;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.Test;

import com.machinapp.runtime.desktop.AamoDroidActivity;
import com.machinapp.runtime.desktop.DesktopRuntime;
import com.machinapp.runtime.desktop.util.Context;

public class SimpleUIShowTest {

	@Test
	public void testShow() {
		/*
		Context context = new Context();
		context.setAppPath(new File(this.getClass().getClassLoader().getResource("./app").getFile()));
		*/
		DesktopRuntime runtime = new DesktopRuntime();
		runtime.start("");
		
	}

}
