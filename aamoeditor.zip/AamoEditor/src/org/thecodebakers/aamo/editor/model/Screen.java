package org.thecodebakers.aamo.editor.model;

import java.util.ArrayList;
import java.util.List;

public class Screen {

	private double version;
	private int uiid;
	private String title;
	private String onLoadScript;
	private String onEndScript;
	private List<Element> elements;
	private String [] events;
	private List<String> menuOptions;

	private String onLeaveScript;
	private String onBackScript;
	private String onMenuSelected;
	private String backgroundColor;
	
	
	
	public String getOnLeaveScript() {
		return onLeaveScript;
	}

	public void setOnLeaveScript(String onLeaveScript) {
		this.onLeaveScript = onLeaveScript;
	}

	public String getOnBackScript() {
		return onBackScript;
	}

	public void setOnBackScript(String onBackScript) {
		this.onBackScript = onBackScript;
	}

	public String getOnMenuSelected() {
		return onMenuSelected;
	}

	public void setOnMenuSelected(String onMenuSelected) {
		this.onMenuSelected = onMenuSelected;
	}

	public String getBackgroundColor() {
		return backgroundColor;
	}

	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}

	public List<String> getMenuOptions() {
		return menuOptions;
	}

	public void setMenuOptions(List<String> menuOptions) {
		this.menuOptions = menuOptions;
	}

	public Screen() {
		super();
		elements = new ArrayList<Element>();
		events = new String[] {"onLoadScript", "onEndScript", "onLeaveScript", "onBackScript", 
				"onMenuSelected"};
	}

	public Screen(double version, int uiid, String title, String onLoadScript,
			String onEndScript) {
		this();
		this.version = version;
		this.uiid = uiid;
		this.title = title;
		this.onLoadScript = onLoadScript;
		this.onEndScript = onEndScript;
	}

	public double getVersion() {
		return version;
	}

	public void setVersion(double version) {
		this.version = version;
	}

	public int getUiid() {
		return uiid;
	}

	public void setUiid(int uiid) {
		this.uiid = uiid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getOnLoadScript() {
		return onLoadScript;
	}

	public void setOnLoadScript(String onLoadScript) {
		this.onLoadScript = onLoadScript;
	}

	public String getOnEndScript() {
		return onEndScript;
	}

	public void setOnEndScript(String onEndScript) {
		this.onEndScript = onEndScript;
	}

	public List<Element> getElements() {
		return elements;
	}

	public void setElements(List<Element> elements) {
		this.elements = elements;
	}

	public String[] getEvents() {
		return events;
	}

	public void setEvents(String[] events) {
		this.events = events;
	}
	
	
	
	
}
