package org.thecodebakers.aamo.editor.model;

import java.util.List;

import javax.swing.JComponent;

import org.thecodebakers.aamo.editor.model.Constants.ControlType;

public class Element implements Cloneable {

	private int id;
	private ControlType type;
	private double percentTop;
	private double percentLeft;
	private double percentWidth;
	private double percentHeight;
	private String text;
	private boolean checked;
	private String onChangeScript;
	private String onClickScript;
	private JComponent component;
	private String [] events;
	private boolean selected;
	
	private String url;
	private String onCompleteScript;
	private String onElementSelected;
	private String picture;
	private boolean stretch;
	
	public List<String> listElements;
	
	
	
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getOnCompleteScript() {
		return onCompleteScript;
	}

	public void setOnCompleteScript(String onCompleteScript) {
		this.onCompleteScript = onCompleteScript;
	}

	public String getOnElementSelected() {
		return onElementSelected;
	}

	public void setOnElementSelected(String onElementSelected) {
		this.onElementSelected = onElementSelected;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public boolean isStretch() {
		return stretch;
	}

	public void setStretch(boolean stretch) {
		this.stretch = stretch;
	}

	public List<String> getListElements() {
		return listElements;
	}

	public void setListElements(List<String> listElements) {
		this.listElements = listElements;
	}

	public Element() {
		super();
		type = ControlType.NONE;
	}

	public Element(int id, ControlType type, double percentTop,
			double percentLeft, double percentWidth, double percentHeight,
			String text, boolean checked, String onChangeScript,
			String onClickScript) {
		this();
		this.id = id;
		this.type = type;
		this.percentTop = percentTop;
		this.percentLeft = percentLeft;
		this.percentWidth = percentWidth;
		this.percentHeight = percentHeight;
		this.text = text;
		this.checked = checked;
		this.onChangeScript = onChangeScript;
		this.onClickScript = onClickScript;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ControlType getType() {
		return type;
	}

	public void setType(ControlType type) {
		this.type = type;
	}

	public double getPercentTop() {
		return percentTop;
	}

	public void setPercentTop(double percentTop) {
		this.percentTop = percentTop;
	}

	public double getPercentLeft() {
		return percentLeft;
	}

	public void setPercentLeft(double percentLeft) {
		this.percentLeft = percentLeft;
	}

	public double getPercentWidth() {
		return percentWidth;
	}

	public void setPercentWidth(double percentWidth) {
		this.percentWidth = percentWidth;
	}

	public double getPercentHeight() {
		return percentHeight;
	}

	public void setPercentHeight(double percentHeight) {
		this.percentHeight = percentHeight;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public String getOnChangeScript() {
		return onChangeScript;
	}

	public void setOnChangeScript(String onChangeScript) {
		this.onChangeScript = onChangeScript;
	}

	public String getOnClickScript() {
		return onClickScript;
	}

	public void setOnClickScript(String onClickScript) {
		this.onClickScript = onClickScript;
	}

	public JComponent getComponent() {
		return component;
	}

	public void setComponent(JComponent component) {
		this.component = component;
	}

	
	
	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public String[] getEvents() {
		return events;
	}

	public void setEvents(String[] events) {
		this.events = events;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Element other = (Element) obj;
		if (id != other.id)
			return false;
		if (type != other.type)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return this.id + ": " + this.type;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		Element el = new Element();
		el.id = this.id;
		el.type = this.type;
		el.percentTop = this.percentTop;
		el.percentLeft = this.percentLeft;
		el.percentWidth = this.percentWidth;
		el.percentHeight = this.percentHeight;
		el.text = this.text;
		el.checked = this.checked;
		el.onChangeScript = this.onChangeScript;
		el.onClickScript = this.onClickScript;
		el.component = null;
		el.events = this.events;
		el.selected = false;
		return el;
	}
	
	
	
}
