package org.thecodebakers.aamo.editor.model;

public class Constants {
	public enum ControlType {NONE, TEXTBOX, LABEL, BUTTON, CHECKBOX, LISTBOX, WEBBOX, IMAGEBOX}; 
}
