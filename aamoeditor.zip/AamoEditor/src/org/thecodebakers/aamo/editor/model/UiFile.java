package org.thecodebakers.aamo.editor.model;

import java.util.UUID;

import javax.swing.JInternalFrame;

public class UiFile {
	private int number;
	private String identifier;
	private String path;
	private Screen screen;
	private JInternalFrame frame;
	private int screenWidth;
	private int screenHeight;
	private boolean changed;
	private int devSelect;
	public UiFile() {
		super();
		screen = new Screen();
		this.identifier = UUID.randomUUID().toString();
	}
	public UiFile(int number, String path, Screen screen) {
		this();
		this.number = number;
		this.path = path;
		this.screen = screen;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public Screen getScreen() {
		return screen;
	}
	public void setScreen(Screen screen) {
		this.screen = screen;
	}
	public JInternalFrame getFrame() {
		return frame;
	}
	public void setFrame(JInternalFrame frame) {
		this.frame = frame;
	}
	public int getScreenWidth() {
		return screenWidth;
	}
	public void setScreenWidth(int screenWidth) {
		this.screenWidth = screenWidth;
	}
	public int getScreenHeight() {
		return screenHeight;
	}
	public void setScreenHeight(int screenHeight) {
		this.screenHeight = screenHeight;
	}
	
	
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public int getDevSelect() {
		return devSelect;
	}
	public void setDevSelect(int devSelect) {
		this.devSelect = devSelect;
	}
	public boolean isChanged() {
		return changed;
	}
	public void setChanged(boolean changed) {
		this.changed = changed;
	}
	public org.thecodebakers.aamo.editor.model.Element getSelectedElement() {
		org.thecodebakers.aamo.editor.model.Element el = null;
		for (org.thecodebakers.aamo.editor.model.Element el1 : this.getScreen().getElements()) {
			if (el1.isSelected()) {
				el = el1;
				break;
			}
		}
		return el;
	}
	@Override
	public boolean equals(Object obj) {
		int objUIID = ((UiFile) obj).getScreen().getUiid();
		String objIdentifier = ((UiFile) obj).getIdentifier();
		return (objUIID == this.getScreen().getUiid() && objIdentifier.equals(this.getIdentifier()));
	}
	@Override
	public int hashCode() {
		return this.getScreen().getUiid();
	}
	
	
	
}
