package org.thecodebakers.aamo.editor.model;

public class CodeEventArg {
	public String originalEventHandlerCode;
	public String newEventHandlerCode;
	public boolean isScreenEvent = false;
	public int uiNumber;
	public int elementNumber;
	public String eventName;
	public String elementType;
}
