package org.thecodebakers.aamo.editor.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;

import javax.swing.Icon;

import org.thecodebakers.aamo.editor.model.Constants.ControlType;

public class ColorIcon implements Icon
{
    private Color color;
    private int width;
    private int height;
    private ControlType type;
    private float dash1[] = { 10.0f };
    private BasicStroke dashed = new BasicStroke(1.0f,
    	      BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash1, 0.0f);

    public ColorIcon(int width, int height, ControlType type)
    {
        this.type = type;
        switch (this.type) {
        case LABEL:
        	this.width = (width == 0) ? 30 : width;
    		this.height = (height == 0) ? 20 : height;
        	break;
        case TEXTBOX:
        	this.width = (width == 0) ? 30 : width;
    		this.height = (height == 0) ? 20 : height;
        	break;
        case BUTTON:
        	this.width = (width == 0) ? 34 : width;
    		this.height = (height == 0) ? 20 : height;
        	break;
        case CHECKBOX:
        	this.width = (width == 0) ? 21 : width;
    		this.height = (height == 0) ? 21 : height;
        	break;
        case LISTBOX:
        	this.width = (width == 0) ? 21 : width;
    		this.height = (height == 0) ? 21 : height;
        	break;
        case WEBBOX:
        	this.width = (width == 0) ? 21 : width;
    		this.height = (height == 0) ? 21 : height;
        	break;   
        case IMAGEBOX:
        	this.width = (width == 0) ? 21 : width;
    		this.height = (height == 0) ? 21 : height;
        	break;        	
        }
    }

    public int getIconWidth()
    {
        return width;
    }

    public int getIconHeight()
    {
        return height;
    }

    public void paintIcon(Component c, Graphics g, int x, int y)
    {
    	Graphics2D g2 = (Graphics2D) g;
    	
    	switch(this.type) {
    	case TEXTBOX:	
    		g2.setColor(Color.white);
    		g2.fillRect(x, y, width, height);
    		g2.setColor(Color.black);
    		g2.drawRect(x, y, width - 1, height - 1);
    		break;
    	case LABEL:
    		Stroke stroke = g2.getStroke();
    		g2.setColor(Color.white);
    		g2.fillRect(x, y, width, height);
    		g2.setColor(Color.black);
    		g2.setStroke(dashed);
    		g2.drawRect(x, y, width - 1, height - 1);
    		g2.setStroke(stroke);
    		break;
    	case BUTTON:
    		g2.setColor(Color.lightGray);
    		g2.fillRoundRect(x, y, width, height, 10, 10);
    		break;
    	case CHECKBOX:
    		g2.setColor(Color.white);
    		g2.fillRect(x, y, width, height);
    		g2.setColor(Color.black);
    		g2.drawRect(x, y, width - 1, height - 1);
    		g2.drawLine(x, y, x + width, y + height);
    		g2.drawLine(x + width, y, x, y + height);
    		break;
    	case WEBBOX:	
    		g2.setColor(Color.black);
    		g2.fillRect(x, y, width, height);
    		g2.setColor(Color.white);
    		g2.drawRect(x, y, width - 1, height - 1);
    		g2.drawLine(x, y, x + width, y + height);
    		g2.drawLine(x + width, y, x, y + height);
    		break;
    	case LISTBOX:	
    		g2.setColor(Color.white);
    		g2.fillRect(x, y, width, height);
    		g2.setColor(Color.black);
    		g2.drawRect(x, y, width - 1, height - 1);
    		for (int i=0; i < height; i+=5) {
    			g2.drawLine(x, y+i, x+width, y+i);
    		}
    		break; 	
    	case IMAGEBOX:	
    		g2.setColor(Color.lightGray);
    		g2.fillRect(x, y, width, height);
    		g2.setColor(Color.white);
    		g2.drawRect(x, y, width - 1, height - 1);
    		g2.drawOval(x, y, width, height);
    		break; 	    		
    	}
    }
}