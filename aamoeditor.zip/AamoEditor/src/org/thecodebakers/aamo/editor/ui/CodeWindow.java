package org.thecodebakers.aamo.editor.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.thecodebakers.aamo.editor.model.CodeEventArg;

public class CodeWindow extends JFrame implements KeyListener, WindowListener {

	private int screenHeight = 400;
	private int screenWidth = 600;
	private boolean alreadyShown = false;
	private Editor editor;
	private ResourceBundle res;
	private JTextArea texto;
	private JPanel statusBar;
	private JLabel lineNumber;
	private CodeEventArg argument;
	
	/*
CWfileMenu=File:70
CWfileMenuNew=New:78
CWfileMenuSave=Save...:83
CWfileMenuExit=Exit:88
CWeditMenu=Edit:69
CWeditMenuCopy=Copy:67
CWeditMenuPaste=Paste:80
CWeditMenuCut=Cut:85
CWeditMenuDelete=Delete:68

CWtitleEditScreenEvent=Editing UI: %d Event: %s
CWtitleEditElementEvent=Editing Element: %d (%s) UI: %d Event: %s
	 */
	

	public CodeWindow(Editor editor, ResourceBundle res) {
		this.editor = editor;
		this.res = res;
	}
	
	public boolean startWindow(CodeEventArg arg) {
		this.argument = arg;
		boolean retorno = false;
		this.setSize(screenWidth, screenHeight);
		this.addWindowListener(this);
		this.setLayout(new BorderLayout());
				
		if (!this.alreadyShown) {
			int x = editor.getScreenLeft() + editor.getScreenWidth() / 2;
			int y = editor.getScreenTop() + editor.getScreenHeight() / 2;
			this.setLocation(x, y);
		}
		
		String titleString = null;
		if (arg.isScreenEvent) {
			titleString = String.format(res.getString("CWtitleEditScreenEvent"),
					arg.uiNumber, arg.eventName);
		}
		else {
			titleString = String.format(res.getString("CWtitleEditElementEvent"),
					arg.elementNumber, arg.elementType, arg.uiNumber, arg.eventName);
		}
		
		this.setTitle(titleString);
		initComponents();
		this.setResizable(true);
		
		this.setVisible(true);
		this.alreadyShown = true;
		return retorno;
	}
	
	
	
	
	private void initComponents() {
		statusBar = new JPanel(new FlowLayout());
		this.getContentPane().add(statusBar,BorderLayout.SOUTH);

		JLabel lblLine = new JLabel(res.getString("CWtitleLineNumber"));
		statusBar.add(lblLine);
		lineNumber = new JLabel("1");
		statusBar.add(lineNumber);
		
		texto = new JTextArea();
		if (this.argument.originalEventHandlerCode != null && this.argument.originalEventHandlerCode.length() > 0) {
			texto.setText(this.argument.originalEventHandlerCode);
		}
		texto.setFont(new Font(Font.MONOSPACED,Font.PLAIN,12));
		this.getContentPane().add(new JScrollPane(texto),BorderLayout.CENTER);
	}

	@Override
	public void windowActivated(WindowEvent arg0) {


	}

	@Override
	public void windowClosed(WindowEvent arg0) {

	}

	@Override
	public void windowClosing(WindowEvent arg0) {
		this.setVisible(false);
		this.dispose();

	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {


	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {


	}

	@Override
	public void windowIconified(WindowEvent arg0) {


	}

	@Override
	public void windowOpened(WindowEvent arg0) {


	}

	@Override
	public void keyPressed(KeyEvent arg0) {


	}

	@Override
	public void keyReleased(KeyEvent arg0) {


	}

	@Override
	public void keyTyped(KeyEvent arg0) {


	}

}
