package org.thecodebakers.aamo.editor.ui;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.thecodebakers.aamo.editor.ui.PropertiesWindow.BtnTask;

public class L10NScreen extends JFrame {

	private Editor editor;
	private int screenHeight;
	private int screenWidth;
	private final int HEIGHT = 500;
	private final int WIDTH = 400;
	
	private TextNote lblL10NfileName;
	private JButton btnReload;
	private JLabel lblNewKey;
	private JTextField txtNewKey;
	private JLabel lblNewText;
	private JTextField txtNewText;
	private JButton btnAddNewKey;
	private JLabel lblTransKeys;
	private JList listTranslations;
	private List<String[]> listText = new ArrayList<String[]>();
	private SelectObserver observer;
	
	public void initComponents() {
		this.setAlwaysOnTop(true);
		this.getContentPane().removeAll();
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setTitle(editor.res.getString("titleL10NScreen"));
		this.screenHeight = HEIGHT;
		this.screenWidth = WIDTH;
		this.setSize(this.screenWidth, this.screenHeight);
		int x = editor.getScreenLeft()+ 50;
		int y = editor.getScreenTop() + 50;
		this.setLocation(x, y);
		this.setLayout(null);
		this.setResizable(false);
		
		JLabel label = new JLabel(editor.res.getString("labL10Nfile"));
		setPercBounds(label,2,2,30,10,false);
		this.getContentPane().add(label);
		
		if (editor.l10nfile != null && editor.l10nfile.length() > 0) {
			lblL10NfileName = new TextNote(editor.l10nfile);
		}
		else {
			lblL10NfileName = new TextNote(editor.res.getString("l10nFileNotSet"));
		}
		lblL10NfileName.setBorder(new LineBorder(Color.black,2));
		setPercBounds(lblL10NfileName,2,11,60,15,false);
		this.getContentPane().add(lblL10NfileName);
		
		JButton btn = new JButton(editor.res.getString("titleOpen"));
		setPercBounds(btn,63,11,20,7,false);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (openOk() && loadList()) {
					setDialogItens(true);
				}
			}
		});
		this.getContentPane().add(btn);
		
		btn = new JButton(editor.res.getString("titleNew"));
		setPercBounds(btn,63,19,20,7,false);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (newOk()) {
					setDialogItens(true);
				}
			}
		});
		this.getContentPane().add(btn);
		
		btnReload = new JButton(editor.res.getString("titleReload"));
		setPercBounds(btnReload,2,28,25,7,false);
		if (editor.l10nfile == null || editor.l10nfile.length() == 0) {
			btnReload.setEnabled(false);
		}
		this.btnReload.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				loadList();
			}
		});
		this.getContentPane().add(btnReload);
		
		lblNewKey = new JLabel(editor.res.getString("labNewKey"));
		setPercBounds(lblNewKey,2,36,25,7,false);
		if (editor.l10nfile == null || editor.l10nfile.length() == 0) {
			lblNewKey.setEnabled(false);
		}
		this.getContentPane().add(lblNewKey);
		
		txtNewKey = new JTextField();
		setPercBounds(txtNewKey,27,36,25,7,false);
		if (editor.l10nfile == null || editor.l10nfile.length() == 0) {
			txtNewKey.setEnabled(false);
		}
		this.getContentPane().add(txtNewKey);
		
		lblNewText = new JLabel(editor.res.getString("labNewText"));
		setPercBounds(lblNewText,2,44,25,7,false);
		if (editor.l10nfile == null || editor.l10nfile.length() == 0) {
			lblNewText.setEnabled(false);
		}
		this.getContentPane().add(lblNewText);
		
		txtNewText = new JTextField();
		setPercBounds(txtNewText,27,44,40,7,false);
		if (editor.l10nfile == null || editor.l10nfile.length() == 0) {
			txtNewText.setEnabled(false);
		}
		this.getContentPane().add(txtNewText);
		
		btnAddNewKey = new JButton();
		btnAddNewKey.setText(editor.res.getString("labAddNewKey"));
		setPercBounds(btnAddNewKey,68,44,28,7,false);
		if (editor.l10nfile == null || editor.l10nfile.length() == 0) {
			btnAddNewKey.setEnabled(false);
		}
		btnAddNewKey.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				addNewTranslation();
			}
		});
		this.getContentPane().add(btnAddNewKey);
		
		this.lblTransKeys = new JLabel(editor.res.getString("labElements"));
		setPercBounds(lblTransKeys,2,52,90,7,false);
		if (editor.l10nfile == null || editor.l10nfile.length() == 0) {
			lblTransKeys.setEnabled(false);
		}
		this.getContentPane().add(lblTransKeys);
		
		this.listTranslations = new JList();
		DefaultListModel lm = new DefaultListModel();
		this.listTranslations.setModel(lm);
		setPercBounds(listTranslations,2,60,94,30,false);
		if (editor.l10nfile == null || editor.l10nfile.length() == 0) {
			listTranslations.setEnabled(false);
		}
		
		this.listTranslations.addMouseListener(new ClickListener() {
			public void singleClick(MouseEvent e) {
                
            }

            public void doubleClick(MouseEvent e) {
            	String resultado = "l10n::" + listText.get(listTranslations.getSelectedIndex())[0];
                observer.setResult(resultado);
                terminar();
            }
		});
		this.getContentPane().add(listTranslations);
		loadList();
		this.setVisible(true);
	}
	
	protected void addNewTranslation() {
		if (this.txtNewKey.getText() != null && 
				this.txtNewKey.getText().length() > 0 &&
				this.txtNewText.getText() != null &&
				this.txtNewText.getText().length() > 0) {
			try {
				FileReader fr = new FileReader(editor.l10nfile);
				BufferedReader br = new BufferedReader(fr);
				StringBuilder tudo = new StringBuilder();
				String linha = null;
				while ((linha = br.readLine()) != null) {
					tudo.append(linha);
					tudo.append("\r\n");
				}
				br.close();
				fr.close();
				FileWriter fw = new FileWriter(editor.l10nfile);
				BufferedWriter bw = new BufferedWriter(fw);
				String newEntry = this.txtNewKey.getText().trim() + "=" + this.txtNewText.getText().trim() + "\r\n";
				tudo.append(newEntry);
				bw.write(tudo.toString());
				loadList();
				bw.close();
				fw.close();
				loadList();
			} catch (IOException e) {
				JOptionPane.showMessageDialog(this, editor.res.getString("msgErrorWritingL10N") +
						": " + e.getLocalizedMessage());
				e.printStackTrace();
			}
		}
		
	}

	protected void terminar() {
		this.setVisible(false);
		this.dispose();
	}

	protected boolean newOk() {
		boolean retorno = false;
		Boolean old = UIManager.getBoolean("FileChooser.readOnly");  
		JFileChooser chooser = null;
		if (editor.l10nfile != null) {
			chooser = new JFileChooser(editor.l10nfile);
		}
		else {
			chooser = new JFileChooser();
		}
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		chooser.setDialogTitle(editor.res.getString("titleCreateL10Nfile"));
	    FileNameExtensionFilter filter = new FileNameExtensionFilter(
	        "L10N files", "properties");
	    chooser.setFileFilter(filter);
	    int returnVal = chooser.showOpenDialog(this);
	    if (returnVal == JFileChooser.APPROVE_OPTION) {
	    	 String name =  chooser.getSelectedFile().getPath() + File.separatorChar +
			    		"aamol10n.properties";
	    	 if (new File(name).exists()) {
			    	int retVal = JOptionPane.showConfirmDialog(this, editor.res.getString("fileAlreadyExists"), 
			    			editor.res.getString("titleCreateL10Nfile"), JOptionPane.YES_NO_OPTION);
			    	if (retVal == JOptionPane.NO_OPTION) {
			    		return false;
			    	}
			 }
	    	 File file = new File(name);
	    	 try {
	    		boolean r = file.delete();
				file.createNewFile();
				listText.clear();
				DefaultListModel lm = (DefaultListModel) this.listTranslations.getModel();
				lm.removeAllElements();
				editor.l10nfile = name;
				this.lblL10NfileName.setText(name);
				retorno = true;
			} catch (IOException e) {
				retorno = false;
			}
	    }
		return retorno;
	}

	protected void setDialogItens(boolean b) {

			btnReload.setEnabled(b);
			lblNewKey.setEnabled(b);
			txtNewKey.setEnabled(b);
			lblNewText.setEnabled(b);
			txtNewText.setEnabled(b);
			btnAddNewKey.setEnabled(b);
			lblTransKeys.setEnabled(b);
			listTranslations.setEnabled(b);			
	}

	private boolean loadList() {
		boolean resultado = true;
		if (editor.l10nfile == null || editor.l10nfile.length() == 0) {
			return false;
		}
		FileReader fr = null;
		BufferedReader br = null;
		try {
			listText.clear();
			DefaultListModel lm = (DefaultListModel) this.listTranslations.getModel();
			lm.removeAllElements();
			fr = new FileReader(editor.l10nfile);
			br = new BufferedReader(fr);
			String linha = null;
			while ((linha = br.readLine()) != null) {
				if (linha.length() > 0) {
					if (linha.charAt(0) != '#') {
						String [] entrada = linha.split("=");
						this.listText.add(entrada);
					}
				}
			}
			
			if (this.listText.size() > 0) {
				String [] listContent = new String[this.listText.size()];
				int x = 0;
				for (String [] entrada : this.listText) {
					listContent[x] = entrada[0].trim() + " : "  + 
										entrada[1].trim();
					lm.addElement(listContent[x++]);
				}
				resultado = true;
			}
			
		} catch (FileNotFoundException e) {
			resultado = false;
			e.printStackTrace();
		} catch (IOException e) {
			resultado = false;
			e.printStackTrace();
		} finally {
			try {
				br.close();
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return resultado;
		
	}

	protected boolean openOk() {
		boolean retorno = false;
		
		JFileChooser chooser = null;
		if (editor.l10nfile != null) {
			chooser = new JFileChooser(editor.l10nfile);
		}
		else {
			chooser = new JFileChooser();
		}
		chooser.setDialogTitle(editor.res.getString("titleOpenL10Nfile"));
	    FileNameExtensionFilter filter = new FileNameExtensionFilter(
	        "L10N files", "properties");
	    chooser.setFileFilter(filter);
	    int returnVal = chooser.showOpenDialog(this);
	    if (returnVal == JFileChooser.APPROVE_OPTION) {
	    	String candidateFile = chooser.getSelectedFile().getName();
	    	if (candidateFile != null && candidateFile.length() > 0 && candidateFile.indexOf("aamol10n") == 0) {
	    		if (candidateFile.indexOf(".properties") > 0) {
	    			editor.l10nfile = chooser.getSelectedFile().getPath();
	    			this.lblL10NfileName.setText(editor.l10nfile);
	    			retorno = true;
	    		}
	    	}
	    }
		return retorno;
	}

	private void setPercBounds(JComponent comp, int left, int top, int width, int height, 
			boolean square) {
		int pTop = (int) ((top / 100.0) * this.screenHeight);
		int pLeft = (int) ((left / 100.0) * this.screenWidth);
		int pHeight = (int) ((height / 100.0) * this.screenHeight);
		int pWidth = pHeight;
		if (!square) {
			pWidth = (int) ((width / 100.0) * this.screenWidth);	
		}
		
		comp.setBounds(pLeft,pTop , pWidth, pHeight);
	}

	public Editor getEditor() {
		return editor;
	}

	public void setEditor(Editor editor) {
		this.editor = editor;
	}

	class TextNote extends JTextArea {
	    public TextNote(String text) {
	        super(text);
	        setBackground(null);
	        setEditable(false);
	        setBorder(null);
	        setLineWrap(true);
	        setWrapStyleWord(true);
	        setFocusable(false);
	    }
	}

	public SelectObserver getObserver() {
		return observer;
	}

	public void setObserver(SelectObserver observer) {
		this.observer = observer;
	}
	

}
