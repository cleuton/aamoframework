package org.thecodebakers.aamo.editor.ui;

import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.ToolTipManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.thecodebakers.aamo.editor.model.CodeEventArg;
import org.thecodebakers.aamo.editor.model.Constants.ControlType;
import org.thecodebakers.aamo.editor.model.Element;
import org.thecodebakers.aamo.editor.model.UiFile;

public class PropertiesWindow extends JFrame implements KeyListener, SelectObserver, WindowListener {

	private int screenHeight = 400;
	private int screenWidth = 600;
	private org.thecodebakers.aamo.editor.model.Element element;
	private UiFile ui;
	private ResourceBundle res;
	
	private SpinnerNumberModel spinWidthModel;
	private JSpinner spinWidth;
	private SpinnerNumberModel spinHeightModel;
	private JSpinner spinHeight;
	private JTextField textTop;
	private JTextField textLeft;
	private JTextField textContent;
	private JCheckBox check;
	private JButton btnSetPosition;
	
	private JLabel labHeight;
	private JLabel labWidth;
	private JTextField textHeight;
	private JTextField textWidth;
	
	private Editor editor;
	private SpinnerNumberModel spinUIIDmodel;
	private JComboBox comboDevices;
	private L10NScreen l10nScreen;
	private ToolTipManager tm;
	private boolean alreadyShown = false;
	
	private CodeWindow codeWindow;
	
	public void startWindow(boolean screen) {
		this.getContentPane().removeAll();
		this.setSize(screenWidth, screenHeight);
		this.addWindowListener(this);
		if (!this.alreadyShown) {
			int x = editor.getScreenLeft() + editor.getScreenWidth() / 2;
			int y = editor.getScreenTop() + editor.getScreenHeight() / 2;
			this.setLocation(x, y);
		}
		
		if (!screen) {
			this.setTitle(String.format(res.getString("titlePropertiesWindow"), 
					this.getElement().getId(),
					this.getElement().getType().name(),
					this.ui.getScreen().getUiid()));	
		}
		else {
			this.setTitle(String.format(res.getString("titlePropsScreen"), 
					this.ui.getScreen().getUiid()));
		}
		
		this.setLayout(null);
		initComponents(screen);
		this.setResizable(false);
		
		this.setVisible(true);
		this.alreadyShown = true;
	}
	
	private void initComponents(boolean screen) {
		this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		JLabel label = null;
		JLabel label2 = null;

		String path = getClass().getClassLoader().getResource(".").getPath();
		ImageIcon img = null;
		JButton btn = null;
		
		if (!screen) {
			
			// ************************* Properties of a control ******************************************

			label = new JLabel(res.getString("labPropPosic"));
			setPercBounds(label,11,1,10,5,false);
			this.getContentPane().add(label);
			
			label2 = new JLabel(res.getString("labPropSize"));
			setPercBounds(label2,60,1,10,5,false);
			this.getContentPane().add(label2);
			
			img = new ImageIcon(path + "/images/setaCima.gif");
			btn = new JButton(img);
			setPercBounds(btn,11,7,10,10,true);
			btn.addMouseListener(new MouseListener() {
				Timer timer = null;
				@Override
				public void mouseClicked(MouseEvent e) {		
				}
				@Override
				public void mouseEntered(MouseEvent e) {		
				}
				@Override
				public void mouseExited(MouseEvent e) {
				}
				@Override
				public void mousePressed(MouseEvent e) {
					timer = new Timer();
					BtnTask task = new BtnTask(-1,0);
			        timer.scheduleAtFixedRate(task, 0, 10);

				}
				@Override
				public void mouseReleased(MouseEvent e) {
					timer.cancel();
					updateTopLeft();
				}
			});

			this.getContentPane().add(btn);
			
			img = new ImageIcon(path + "/images/setaEsquerda.gif");
			btn = new JButton(img);
			setPercBounds(btn,3,14,10,10,true);
			btn.addMouseListener(new MouseListener() {
				Timer timer = null;
				@Override
				public void mouseClicked(MouseEvent e) {		
				}
				@Override
				public void mouseEntered(MouseEvent e) {		
				}
				@Override
				public void mouseExited(MouseEvent e) {
				}
				@Override
				public void mousePressed(MouseEvent e) {
					timer = new Timer();
					BtnTask task = new BtnTask(0,-1);
			        timer.scheduleAtFixedRate(task, 0, 10);

				}
				@Override
				public void mouseReleased(MouseEvent e) {
					timer.cancel();
					updateLeftRight();
				}
			});
			this.getContentPane().add(btn);
			
			img = new ImageIcon(path + "/images/setaBaixo.gif");
			btn = new JButton(img);
			setPercBounds(btn,11,18,10,10,true);
			btn.addMouseListener(new MouseListener() {
				Timer timer = null;
				@Override
				public void mouseClicked(MouseEvent e) {		
				}
				@Override
				public void mouseEntered(MouseEvent e) {		
				}
				@Override
				public void mouseExited(MouseEvent e) {
				}
				@Override
				public void mousePressed(MouseEvent e) {
					timer = new Timer();
					BtnTask task = new BtnTask(+1,0);
			        timer.scheduleAtFixedRate(task, 0, 10);

				}
				@Override
				public void mouseReleased(MouseEvent e) {
					timer.cancel();
					updateTopLeft();
				}
			});
			this.getContentPane().add(btn);
			
			img = new ImageIcon(path + "/images/setaDireita.gif");
			btn = new JButton(img);
			setPercBounds(btn,19,14,10,10,true);
			btn.addMouseListener(new MouseListener() {
				Timer timer = null;
				@Override
				public void mouseClicked(MouseEvent e) {		
				}
				@Override
				public void mouseEntered(MouseEvent e) {		
				}
				@Override
				public void mouseExited(MouseEvent e) {
				}
				@Override
				public void mousePressed(MouseEvent e) {
					timer = new Timer();
					BtnTask task = new BtnTask(0,+1);
			        timer.scheduleAtFixedRate(task, 0, 10);

				}
				@Override
				public void mouseReleased(MouseEvent e) {
					timer.cancel();
					updateLeftRight();
				}
			});
			this.getContentPane().add(btn);
			
			label = new JLabel("% " + res.getString("labPropWidth"));
			setPercBounds(label,45,9,10,5,false);
			this.getContentPane().add(label);
			
			spinWidthModel = new SpinnerNumberModel(1, 1, 100, 1);
			spinWidth = new JSpinner(spinWidthModel);
			setPercBounds(spinWidth,45,14,10,5,false);
			spinWidthModel.setValue(new Integer((int) this.getElement().getPercentWidth()));
			spinWidth.addChangeListener(new ChangeListener() {
				@Override
				public void stateChanged(ChangeEvent e) {
					resizeControl(true, false);
				}
			});
			this.getContentPane().add(spinWidth);
			
			label = new JLabel("% " + res.getString("labPropHeight"));
			setPercBounds(label,70,9,10,5,false);
			this.getContentPane().add(label);
			
			spinHeightModel = new SpinnerNumberModel(1, 1, 100, 1);
			spinHeight = new JSpinner(spinHeightModel);
			setPercBounds(spinHeight,70,14,10,5,false);
			spinHeightModel.setValue(new Integer((int) this.getElement().getPercentHeight()));
			spinHeight.addChangeListener(new ChangeListener() {
				@Override
				public void stateChanged(ChangeEvent e) {
					resizeControl(false, true);
				}
			});
			this.getContentPane().add(spinHeight);
			
			label = new JLabel("% " + res.getString("labPropTop"));
			setPercBounds(label,3,30,12,5,false);
			this.getContentPane().add(label);
			
			textTop = new JTextField();
			setPercBounds(textTop,15,30,10,5,false);
			textTop.setText(((int)this.getElement().getPercentTop()) + "");
			textTop.addKeyListener(this);
			this.getContentPane().add(textTop);
			
			label = new JLabel("% " + res.getString("labPropLeft"));
			setPercBounds(label,3,36,12,5,false);
			this.getContentPane().add(label);
			
			textLeft = new JTextField();
			setPercBounds(textLeft,15,36,10,5,false);
			textLeft.setText(((int)this.getElement().getPercentLeft()) + "");
			textLeft.addKeyListener(this);
			this.getContentPane().add(textLeft);
			
			btnSetPosition = new JButton(res.getString("labBtnSetPosition"));
			setPercBounds(btnSetPosition,15,41,24,5,false);
			btnSetPosition.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					alterTop();
					alterLeft();
				}
			});
			this.getContentPane().add(btnSetPosition);
			
			if (this.getElement().getType() == ControlType.BUTTON || 
					this.getElement().getType() == ControlType.LABEL ||
					this.getElement().getType() == ControlType.TEXTBOX) {
				label = new JLabel(res.getString("labPropText"));
				setPercBounds(label,45,30,10,5,false);
				this.getContentPane().add(label);
				
				textContent = new JTextField();
				setPercBounds(textContent,52,30,40,5,false);
				textContent.setText(this.getElement().getText());
				textContent.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						JTextField txt = (JTextField) e.getSource();
						getElement().setText(txt.getText());
						JLabel lbl = (JLabel) getElement().getComponent();
						lbl.setText(txt.getText());
						markChanged();
					}
				});
				textContent.addKeyListener(new KeyListener() {
					@Override
					public void keyPressed(KeyEvent e) {
						if (e.getKeyChar() == KeyEvent.VK_SPACE &&
								(e.getModifiersEx() ^ e.CTRL_DOWN_MASK) == 0) {
							getTranslationKey();
						}
					}

					@Override
					public void keyReleased(KeyEvent e) {
						
					}

					@Override
					public void keyTyped(KeyEvent e) {
						
					}
				});
				
				textContent.setToolTipText(res.getString("toolTipL10N"));
				tm = ToolTipManager.sharedInstance();
				tm.setInitialDelay(0);
				tm.setDismissDelay(10000);
				tm.registerComponent(textContent);
				this.getContentPane().add(textContent);	
			}

			if (this.getElement().getType() == ControlType.CHECKBOX) {
				label = new JLabel(res.getString("labPropChecked"));
				setPercBounds(label,45,38,10,5,false);
				this.getContentPane().add(label);
				
				check = new JCheckBox();
				setPercBounds(check,52,36,0,10,true);
				check.setSelected(this.getElement().isChecked());
				check.addChangeListener(new ChangeListener() {
					@Override
					public void stateChanged(ChangeEvent e) {
						JCheckBox chk = (JCheckBox) e.getSource();
						getElement().setChecked(chk.isSelected());
						markChanged();
					}
				});

				this.getContentPane().add(check);			
			}
			if (this.getElement().getEvents() != null &&
					this.getElement().getEvents().length > 0) {
				String [] data = this.getElementEvents(this.getElement());
				final JList lista = new JList(data);
				setPercBounds(lista,2,50,95,40,false);
				this.getContentPane().add(lista);
				lista.setToolTipText(res.getString("PWeventListtoolTip"));
				
				lista.addMouseListener(new MouseAdapter() {
				    public void mouseClicked(MouseEvent evt) {
				        JList list = (JList)evt.getSource();
				        if (list.getModel().getSize() > 0) {
				        	 if (evt.getClickCount() == 2) {
						           int index = list.locationToIndex(evt.getPoint());
						           if (changeElementEventHandler(index, (String) list.getSelectedValue())) {
						        	   markChanged();
						        	   lista.setListData(getElementEvents(getElement()));
						           }
						     } 
				        }
				       
				    }
				});
				
				lista.addKeyListener(new KeyListener() {

					@Override
					public void keyPressed(KeyEvent arg0) {
						if (arg0.getKeyChar() == KeyEvent.VK_SPACE &&
								(arg0.getModifiersEx() ^ arg0.CTRL_DOWN_MASK) == 0) {
							changeElementExternalEventHandler(lista);
						}						
					}

					@Override
					public void keyReleased(KeyEvent arg0) {
					}

					@Override
					public void keyTyped(KeyEvent arg0) {
					}
					
				}
				);
				
			}
		}
		else {
			
			// ************************* Properties of a screen ******************************************
			label = new JLabel(res.getString("labSpinScreenUIID"));
			setPercBounds(label,3,1,20,5,false);
			this.getContentPane().add(label);
			
			spinUIIDmodel = new SpinnerNumberModel(1, 1, 100, 1);
			JSpinner spinUIID = new JSpinner(spinUIIDmodel);
			setPercBounds(spinUIID,24,1,10,5,false);
			spinUIIDmodel.setValue(new Integer((int) this.getUi().getScreen().getUiid()));
			
			this.getContentPane().add(spinUIID);
			
			label = new JLabel(res.getString("titleDeviceSelect"));
			setPercBounds(label,50,1,30,5,false);
			this.getContentPane().add(label);
			
			comboDevices = new JComboBox(editor.deviceName);
			int selected = 0;
			if (editor.currentDeviceIndex < 0) {
				selected = editor.deviceName.length - 1;
			}
			else {
				selected = this.getUi().getDevSelect();
			}
			comboDevices.setSelectedIndex(selected);
			comboDevices.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					if (comboDevices.getSelectedIndex() == (editor.deviceName.length - 1)) {
						labWidth.setVisible(true);
						textWidth.setVisible(true);
						labHeight.setVisible(true);
						textHeight.setVisible(true);
					}
					else {
						labWidth.setVisible(false);
						textWidth.setVisible(false);
						labHeight.setVisible(false);
						textHeight.setVisible(false);
					}
				}
			});
			setPercBounds(comboDevices,50,7,30,5,false);

			this.getContentPane().add(comboDevices);
			
			labWidth = new JLabel(res.getString("labWidth"));
			setPercBounds(labWidth,3,14,20,5,false);
			labWidth.setVisible(false);
			this.getContentPane().add(labWidth);
			
			textWidth = new JTextField();
			setPercBounds(textWidth,24,14,20,5,false);
			textWidth.setVisible(false);
			textWidth.addKeyListener(this);
			this.getContentPane().add(textWidth);
			
			labHeight = new JLabel(res.getString("labHeight"));
			setPercBounds(labHeight,50,14,20,5,false);
			labHeight.setVisible(false);
			this.getContentPane().add(labHeight);
			
			textHeight = new JTextField();
			setPercBounds(textHeight,70,14,20,5,false);
			textHeight.setVisible(false);
			textHeight.addKeyListener(this);
			this.getContentPane().add(textHeight);
			
			String [] data = this.getScreenEvents();
			final JList lista = new JList(data);
			setPercBounds(lista,2,70,95,30,false);
			this.getContentPane().add(lista);
			lista.addMouseListener(new MouseAdapter() {
			    public void mouseClicked(MouseEvent evt) {
			        JList list = (JList)evt.getSource();
			        if (list.getModel().getSize() > 0) {
			        	 if (evt.getClickCount() == 2) {
					           int index = list.locationToIndex(evt.getPoint());
					           if (changeScreenEventHandler(index, (String) list.getSelectedValue())) {
					        	   markChanged();
					        	   lista.setListData(getScreenEvents());
					           }
					     } 
			        }
			       
			    }
			});
			
			
			// Bot�o ok
			
			btn = new JButton(res.getString("labApply"));
			setPercBounds(btn,40,45,20,10,false);
			btn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					if (getUi().getScreen().getUiid() != ((Integer)spinUIIDmodel.getValue()).intValue()) {
						renameUi((Integer) spinUIIDmodel.getValue());
					}
					int selected = 0;
					if (editor.currentDeviceIndex < 0) {
						selected = editor.deviceName.length - 1;
					}
					else {
						selected = getUi().getDevSelect();
					}
					if (selected != comboDevices.getSelectedIndex()) {
						changeSize();
					}
				}
			});
			this.getContentPane().add(btn);
		}

	
	}


	protected void changeElementExternalEventHandler(JList lista) {
		if (lista.getSelectedIndex() < 0) {
			JOptionPane.showMessageDialog(this, res.getString("PWselectAnEvent"));
			return;
		}
		if (((String)lista.getSelectedValue()).contains("lua::")) {
			JOptionPane.showMessageDialog(this, res.getString("PWnotAnExternalHandler"));
			return;
		}
		// � um nome de arquivo "lua"
		String currentEventHandler = (String) lista.getSelectedValue();
		int posIni = currentEventHandler.indexOf(": ");
		if (posIni > 0) {
			currentEventHandler = currentEventHandler.substring(posIni + 2);
		}
	
		try {
			if (editor.currentSelectedUi.isChanged()) {
				JOptionPane.showMessageDialog(this, res.getString("codeWindowUInotSaved"));
				return;
			}
			CodeEventArg arg = new CodeEventArg();
			File dir = new File (editor.currentSelectedUi.getPath());
			dir = dir.getParentFile();
			File arqEvento = new File (dir.getPath() + "/" + currentEventHandler + ".lua");
			if (arqEvento.exists()) {
				FileReader fr = new FileReader(arqEvento);
				BufferedReader br = new BufferedReader(fr);
				String line = null;
				StringBuffer sb = new StringBuffer();
				String separator = System.getProperty("line.separator");
				while ((line = br.readLine()) != null) {
					sb.append(line + separator);
				}
				br.close();
				fr.close();
				arg.originalEventHandlerCode = sb.toString();
			}
			arg.uiNumber = editor.currentSelectedUi.getNumber();
			arg.elementNumber = this.getElement().getId();
			arg.isScreenEvent = false;
			arg.eventName = this.getElement().getEvents()[lista.getSelectedIndex()];
			arg.elementType = this.getElement().getType().name();
			if (codeWindow == null) {
				codeWindow = new CodeWindow(editor, res);
			}
			if (codeWindow.startWindow(arg)) {
				
			}

		}
		catch (FileNotFoundException fnf) {
			JOptionPane.showMessageDialog(this, String.format(res.getString("unEspectedError"), "changeElementEventHandler", fnf.getMessage()));
			return;
		} 
		catch (IOException e) {
			JOptionPane.showMessageDialog(this, String.format(res.getString("unEspectedError"), "changeElementEventHandler", e.getMessage()));
			return;
		}
		
	}
	
	protected boolean changeElementEventHandler(int index, String currentEventHandler) {
		
		String eventHandler = "";
		int posIni = currentEventHandler.indexOf(": ");
		if (posIni > 0) {
			eventHandler = currentEventHandler.substring(posIni + 2);
		}
		String oldEH = eventHandler;
		eventHandler = (String) JOptionPane.showInputDialog(this, res.getString("toolTipEH"), 
				res.getString("titleEventHandler"), JOptionPane.QUESTION_MESSAGE, null, null, eventHandler);
		if (eventHandler == null || eventHandler.equals(oldEH)) {
			return false;
		}
		
		if (this.getElement().getEvents()[index].equals("onChangeScript")) {
			this.getElement().setOnChangeScript(eventHandler);
		}
		else if (this.getElement().getEvents()[index].equals("onClickScript")) {
				this.getElement().setOnClickScript(eventHandler);
		}
		else if (this.getElement().getEvents()[index].equals("onCompleteScript")) {
				this.getElement().setOnCompleteScript(eventHandler);
		}
		else if (this.getElement().getEvents()[index].equals("onElementSelected")) {
				this.getElement().setOnElementSelected(eventHandler);
		}
		return true;
		
	}
	
	protected boolean changeScreenEventHandler(int index, String currentEventHandler) {
		String eventHandler = "";
		int posIni = currentEventHandler.indexOf(": ");
		if (posIni > 0) {
			eventHandler = currentEventHandler.substring(posIni + 2);
		}
		String oldEH = eventHandler;
		eventHandler = (String) JOptionPane.showInputDialog(this, res.getString("toolTipEH"), 
				res.getString("titleEventHandler"), JOptionPane.QUESTION_MESSAGE, null, null, eventHandler);
		if (eventHandler == null || eventHandler.equals(oldEH)) {
			return false;
		}
		
		if (this.getUi().getScreen().getEvents()[index].equals("onLoadScript")) {
			this.getUi().getScreen().setOnLoadScript(eventHandler);
		}
		else if (this.getUi().getScreen().getEvents()[index].equals("onEndScript")) {
				this.getUi().getScreen().setOnEndScript(eventHandler);
		}
		else if (this.getUi().getScreen().getEvents()[index].equals("onLeaveScript")) {
				this.getUi().getScreen().setOnLeaveScript(eventHandler);
		}
		else if (this.getUi().getScreen().getEvents()[index].equals("onBackScript")) {
				this.getUi().getScreen().setOnBackScript(eventHandler);
		}
		else if (this.getUi().getScreen().getEvents()[index].equals("onMenuSelected")) {
				this.getUi().getScreen().setOnMenuSelected(eventHandler);
		}

		return true;
	}

	private String[] getScreenEvents() {
		// this.getUi().getScreen().getEvents();
		String [] events = new String[this.getUi().getScreen().getEvents().length];
		for (int x = 0; x < events.length; x++) {
			StringBuilder sb = new StringBuilder();
			sb.append(this.getUi().getScreen().getEvents()[x]);
			if (this.getUi().getScreen().getEvents()[x].equals("onLoadScript")) {
				if (this.getUi().getScreen().getOnLoadScript() != null && this.getUi().getScreen().getOnLoadScript().length() > 0) {
					sb.append(": " + this.getUi().getScreen().getOnLoadScript());
				}
			}
			else if (this.getUi().getScreen().getEvents()[x].equals("onEndScript")) {
				if (this.getUi().getScreen().getOnEndScript() != null && this.getUi().getScreen().getOnEndScript().length() > 0) {
					sb.append(": " + this.getUi().getScreen().getOnEndScript());
				}
			}
			else if (this.getUi().getScreen().getEvents()[x].equals("onLeaveScript")) {
				if (this.getUi().getScreen().getOnLeaveScript() != null && this.getUi().getScreen().getOnLeaveScript().length() > 0) {
					sb.append(": " + this.getUi().getScreen().getOnLeaveScript());
				}
			}
			else if (this.getUi().getScreen().getEvents()[x].equals("onBackScript")) {
				if (this.getUi().getScreen().getOnBackScript() != null && this.getUi().getScreen().getOnBackScript().length() > 0) {
					sb.append(": " + this.getUi().getScreen().getOnBackScript());
				}
			}
			else if (this.getUi().getScreen().getEvents()[x].equals("onMenuSelected")) {
				if (this.getUi().getScreen().getOnMenuSelected() != null && this.getUi().getScreen().getOnMenuSelected().length() > 0) {
					sb.append(": " + this.getUi().getScreen().getOnMenuSelected());
				}
			}


			events[x] = sb.toString();
			
		}
		return events;
	}

	private String[] getElementEvents(Element element2) {
		String [] events = new String[element2.getEvents().length];
		for (int x = 0; x < events.length; x++) {
			StringBuilder sb = new StringBuilder();
			sb.append(element2.getEvents()[x]);
			if (element2.getEvents()[x].equals("onChangeScript")) {
				if (element.getOnChangeScript() != null && element.getOnChangeScript().length() > 0) {
					sb.append(": " + element2.getOnChangeScript());
				}
			}
			else if (element2.getEvents()[x].equals("onClickScript")) {
				if (element.getOnClickScript() != null && element.getOnClickScript().length() > 0) {
					sb.append(": " + element2.getOnClickScript());
				}
			}
			else if (element2.getEvents()[x].equals("onCompleteScript")) {
				if (element.getOnCompleteScript() != null && element.getOnCompleteScript().length() > 0) {
					sb.append(": " + element2.getOnCompleteScript());
				}
			}
			else if (element2.getEvents()[x].equals("onElementSelected")) {
				if (element.getOnElementSelected() != null && element.getOnElementSelected().length() > 0) {
					sb.append(": " + element2.getOnElementSelected());
				}
			}
			
			events[x] = sb.toString();
			
		}
		return events;
	}

	protected void getTranslationKey() {
		if (l10nScreen == null) {
			l10nScreen = new L10NScreen();
			l10nScreen.setEditor(this.editor);
			l10nScreen.setObserver(this);

		}
		l10nScreen.initComponents();
	}
	

	protected void changeSize() {
		if (comboDevices.getSelectedIndex() < (editor.deviceName.length - 1)) {
			editor.screenWidth = Integer.parseInt(editor.devices[comboDevices.getSelectedIndex()][1]);
			editor.screenHeight = Integer.parseInt(editor.devices[comboDevices.getSelectedIndex()][2]);
			editor.currentDeviceIndex = comboDevices.getSelectedIndex();
			editor.changeSelectedScreen();
		}
		else {
			if (textWidth.getText() != null && textWidth.getText().length() > 0 &&
					textHeight.getText() != null & textHeight.getText().length() > 0) {
				editor.screenWidth = Integer.parseInt(textWidth.getText());
				editor.screenHeight = Integer.parseInt(textHeight.getText());
				editor.currentDeviceIndex = -99;
				editor.changeSelectedScreen();				
			}
			else {
				JOptionPane.showMessageDialog(this, res.getString("msgMissingSize"));
			}
		}
		
	}

	protected void renameUi(Integer value) {
		this.getUi().getScreen().setUiid(value.intValue());
		this.getUi().getFrame().setTitle("*UI " + value.intValue());
		this.getUi().setChanged(true);
	}

	private void setPercBounds(JComponent comp, int left, int top, int width, int height, 
			boolean square) {
		int pTop = (int) ((top / 100.0) * this.screenHeight);
		int pLeft = (int) ((left / 100.0) * this.screenWidth);
		int pHeight = (int) ((height / 100.0) * this.screenHeight);
		int pWidth = pHeight;
		if (!square) {
			pWidth = (int) ((width / 100.0) * this.screenWidth);	
		}
		
		comp.setBounds(pLeft,pTop , pWidth, pHeight);
	}



	// Getters, Setters
	
	public int getScreenHeight() {
		return screenHeight;
	}

	public void setScreenHeight(int screenHeight) {
		this.screenHeight = screenHeight;
	}

	public int getScreenWidth() {
		return screenWidth;
	}

	public void setScreenWidth(int screenWidth) {
		this.screenWidth = screenWidth;
	}

	public org.thecodebakers.aamo.editor.model.Element getElement() {
		return element;
	}

	public void setElement(org.thecodebakers.aamo.editor.model.Element element) {
		this.element = element;
	}

	public void setRes(ResourceBundle res) {
		this.res = res;
	}

	public void setUi(UiFile ui) {
		this.ui = ui;
	}

	public Editor getEditor() {
		return editor;
	}

	public void setEditor(Editor editor) {
		this.editor = editor;
	}
	
	public JTextField getTextTop() {
		return textTop;
	}

	public void setTextTop(JTextField textTop) {
		this.textTop = textTop;
	}

	public JTextField getTextLeft() {
		return textLeft;
	}

	public void setTextLeft(JTextField textLeft) {
		this.textLeft = textLeft;
	}
	
	

	public UiFile getUi() {
		return ui;
	}



	class BtnTask extends TimerTask {
		int vert = 0;
		int horiz = 0;
		BtnTask() {
			super();
		}
		
		BtnTask(int vert, int horiz) {
			this.vert = vert;
			this.horiz = horiz;
		}
		
        public void run() {
        	editor.moveControl(vert, horiz);
        }
        	
    }
	
	protected void updateTopLeft() {
    	org.thecodebakers.aamo.editor.model.Element el = ui.getSelectedElement();
    	Rectangle rect = el.getComponent().getBounds();
    	int topPercent = (int) Math.round(((double)rect.y / (double)ui.getScreenHeight()) * 100.0d);
    	getTextTop().setText(topPercent + "");
    	btnSetPosition.doClick();
    	markChanged();
	}
	
	protected void updateLeftRight() {
		org.thecodebakers.aamo.editor.model.Element el = ui.getSelectedElement();
    	Rectangle rect = el.getComponent().getBounds();
    	int leftPercent = (int) Math.round(((double)rect.x / (double)ui.getScreenWidth()) * 100.0d);
    	getTextLeft().setText(leftPercent + "");
    	btnSetPosition.doClick();
    	markChanged();
	}

	protected void alterTop() {
		org.thecodebakers.aamo.editor.model.Element el = ui.getSelectedElement();
    	Rectangle rect = el.getComponent().getBounds();
    	int newTop = Integer.parseInt(getTextTop().getText());
    	rect.y = (int) (newTop / 100.00d * ui.getScreenHeight());
    	el.getComponent().setBounds(rect);
    	el.setPercentTop(newTop);
    	markChanged();
	}
	
	protected void alterLeft() {
		org.thecodebakers.aamo.editor.model.Element el = ui.getSelectedElement();
    	Rectangle rect = el.getComponent().getBounds();
    	int newLeft = Integer.parseInt(getTextLeft().getText());
    	rect.x = (int) (newLeft / 100.00d * ui.getScreenWidth());
    	el.getComponent().setBounds(rect);
    	el.setPercentLeft(newLeft);
    	markChanged();
    	
	}
	
	protected void resizeControl(boolean horizontal, boolean vertical) {
		int valorH = 0;
		int valorV = 0;
		if (horizontal) {
			valorH = Integer.parseInt(spinWidthModel.getValue().toString());
		}
		else {
			valorV = Integer.parseInt(spinHeightModel.getValue().toString());
		}
		editor.resizeControl(valorV, valorH);
		markChanged();
	}
	
	protected void markChanged() {
		if (!this.getUi().isChanged()) {
			JInternalFrame frame = this.getUi().getFrame();
			frame.setTitle("*" + frame.getTitle());
			this.getUi().setChanged(true);			
		}
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		
		
	}

	@Override
	public void keyTyped(KeyEvent e) {

        char c = e.getKeyChar();
        if (!((c >= '0') && (c <= '9') ||
           (c == KeyEvent.VK_BACK_SPACE) ||
           (c == KeyEvent.VK_DELETE))) {
          getToolkit().beep();
          e.consume();
        }
		
	}

	@Override
	public void setResult(Object obj) {
		this.textContent.setText((String) obj);
		
	}

	@Override
	public void windowActivated(WindowEvent arg0) {
		// 
		
	}

	@Override
	public void windowClosed(WindowEvent arg0) {
		// T
		
	}

	@Override
	public void windowClosing(WindowEvent arg0) {
		if (l10nScreen != null) {
			if (l10nScreen.isVisible()) {
				l10nScreen.setVisible(false);
				l10nScreen.dispose();
			}
		}
		
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		
		
	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		
		
	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		
		
	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		
		
	}

}
