package org.thecodebakers.aamo.editor.ui;

public interface SelectObserver {
	public void setResult(Object obj);
}
