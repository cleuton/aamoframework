package org.thecodebakers.aamo.editor.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.beans.PropertyVetoException;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.border.LineBorder;
import javax.swing.event.InternalFrameEvent;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.NumberFormatter;

import org.thecodebakers.aamo.editor.business.XMLinterface;
import org.thecodebakers.aamo.editor.model.Constants.ControlType;
import org.thecodebakers.aamo.editor.model.Element;
import org.thecodebakers.aamo.editor.model.Screen;
import org.thecodebakers.aamo.editor.model.UiFile;

import com.machinapp.runtime.desktop.DesktopRuntime;
import com.tomtessier.scrollabledesktop.BaseInternalFrame;
import com.tomtessier.scrollabledesktop.JScrollableDesktopPane;

public class Editor extends JFrame implements ActionListener, KeyListener, MouseListener, FocusListener {

	public static final double AAMO_VERSION = 1.0d;
	public int screenWidth = 320;
	public int screenHeight = 480;
	public int screenTop = 0;
	public int screenLeft = 0;
	private Dimension initPanel = new Dimension(400,500);
	private int windowWidth = 800;
	private int windowHeight = 700;
	public ResourceBundle res;
	private enum menuCodes {FILE_NEW, FILE_OPEN, FILE_SAVE, FILE_SAVE_AS, EXIT,
		EDIT_COPY, EDIT_PASTE, EDIT_CUT, EDIT_DELETE, EDIT_INSERT_CONTROL, 
		EDIT_INSERT_LABEL, EDIT_INSERT_TEXTBOX, EDIT_INSERT_BUTTON, EDIT_INSERT_CHECKBOX,
		EDIT_SCREEN_PROPERTIES, PROJECT_RUN, PROJECT_ANDROID_SDK, 
		PROJECT_ANDROID_CREATE_PROJECT, PROJECT_ANDROID_AVD_MANAGER,
		PROJECT_ANDROID_SDK_MANAGER,
		PROJECT_ANDROID_RUN_PROJECT};
	public String [][] devices;
	public Object [] deviceName;
	private JPanel externo;
	private JPanel tela;
	private JScrollPane painel;
	private JScrollableDesktopPane desktop;
	
	private String lastDirectory = ".";
	
	public List<UiFile> files;
	public UiFile currentSelectedUi;
	
	private PropertiesWindow propertiesWindow;
	private JMenuItem menuItemScreenProps;
	
	private String [][] commonEvents = {
			{"onLoadScript", "onEndScript"}, // Screen events (0)
			{}, // TextBox events
			{}, // Label events
			{"onClickScript"}, // Button events
			{"onChangeScript"},  // CheckBox events
			{"onElementSelected"},  // LISTBOX events
			{},  // WEBBOX events
			{"onClickScript"}   // IMAGEBOX events
	};
	
	public int currentDeviceIndex;
	public Object lastCopy;
	public boolean lastCopyIsText;
	public boolean aControlIsSelected;
	public org.thecodebakers.aamo.editor.model.Element selectedControl;
	
	// Edit menu
	
	public JMenuItem fileMenuSave;
	public JMenuItem fileMenuSaveAs;
	public JMenuItem editMenuCopy;
	public JMenuItem editMenuPaste;
	public JMenuItem editMenuCut;
	public JMenuItem editMenuDelete;
	public JMenu editMenuInsertControl;
	public JMenuItem editMenuInsertLabel;
	public JMenuItem editMenuInsertTextBox;
	public JMenuItem editMenuInsertButton;
	public JMenuItem editMenuInsertCheckBox;
	public JMenuItem projectMenuRun;
	public JMenu projectMenuAndroid;
	public JMenuItem projectMenuAndroidSdk;
	public JMenuItem projectMenuAndroidCreateProject;
	public JMenuItem projectMenuAndroidExecAVDManager;
	public JMenuItem projectMenuAndroidExecSDKManager;
	public JMenuItem projectMenuAndroidRunProject;
	public Editor selfRef;
	
	// L10N
	
	public String l10nfile;
	
	public static void main(String[] args) {
		Editor editor = new Editor();
		editor.selfRef = editor;
		editor.res = ResourceBundle.getBundle("org.thecodebakers.aamo.editor.resources.editor");
		editor.initComponents();
	}

	private void initComponents() {
		files = new ArrayList<UiFile>();
		prepareDevicesList();
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new WindowListener() {
			@Override
			public void windowActivated(WindowEvent arg0) {
			}
			@Override
			public void windowClosed(WindowEvent arg0) {
			}
			@Override
			public void windowClosing(WindowEvent e) {
				if (terminate()) {
					System.exit(0);
				}
			}
			@Override
			public void windowDeactivated(WindowEvent arg0) {
			}
			@Override
			public void windowDeiconified(WindowEvent arg0) {
			}
			@Override
			public void windowIconified(WindowEvent arg0) {
			}
			@Override
			public void windowOpened(WindowEvent arg0) {
			}
		});
		
		createMenu();
		
		this.setSize(this.windowWidth, this.windowHeight);
		this.setTitle(res.getString("title"));
		
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		int w = this.getSize().width;
		int h = this.getSize().height;
		int x = (dim.width-w)/2;
		int y = (dim.height-h)/2;
		this.setLocation(x, y);
		this.setScreenTop(y);
		this.setScreenLeft(x);
		this.setVisible(true);
	}

	private void createMenu() {
		JMenuBar menuBar = new JMenuBar();
		
		// "FILE" Menu
		String [] xMenu = res.getString("fileMenu").split(":");
		JMenu menu = new JMenu(xMenu[0]);
		menu.setMnemonic(Integer.parseInt(xMenu[1]));
		
		// File New
		xMenu = res.getString("fileMenuNew").split(":");
		JMenuItem menuItem = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		menuItem.setName(menuCodes.FILE_NEW.ordinal() + "");
		menuItem.addActionListener(this);
		menu.add(menuItem);
		
		// File Open
		xMenu = res.getString("fileMenuOpen").split(":");
		menuItem = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		menuItem.setName(menuCodes.FILE_OPEN.ordinal() + "");
		menuItem.addActionListener(this);
		menu.add(menuItem);
		
		// File Save
		xMenu = res.getString("fileMenuSave").split(":");
		this.fileMenuSave = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.fileMenuSave.setName(menuCodes.FILE_SAVE.ordinal() + "");
		this.fileMenuSave.addActionListener(this);
		this.fileMenuSave.setEnabled(false);
		menu.add(this.fileMenuSave);
		
		// File Save As
		xMenu = res.getString("fileMenuSaveAs").split(":");
		this.fileMenuSaveAs = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.fileMenuSaveAs.setName(menuCodes.FILE_SAVE_AS.ordinal() + "");
		this.fileMenuSaveAs.addActionListener(this);
		this.fileMenuSaveAs.setEnabled(false);
		menu.add(this.fileMenuSaveAs);		
		menuBar.add(menu);
		
		menu.addSeparator();
		
		// File Exit
		xMenu = res.getString("fileMenuExit").split(":");
		menuItem = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		menuItem.setName(menuCodes.EXIT.ordinal() + "");
		menuItem.addActionListener(this);
		menu.add(menuItem);		
		menuBar.add(menu);		
		
		// Edit Menu
		
		xMenu = res.getString("editMenu").split(":");
		menu = new JMenu(xMenu[0]);
		menu.setMnemonic(Integer.parseInt(xMenu[1]));
		menuBar.add(menu);
		
		xMenu = res.getString("editMenuCopy").split(":");
		this.editMenuCopy = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.editMenuCopy.setName(menuCodes.EDIT_COPY.ordinal() + "");
		this.editMenuCopy.addActionListener(this);
		this.editMenuCopy.setEnabled(false);
		menu.add(this.editMenuCopy);
		
		xMenu = res.getString("editMenuPaste").split(":");
		this.editMenuPaste = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.editMenuPaste.setName(menuCodes.EDIT_PASTE.ordinal() + "");
		this.editMenuPaste.addActionListener(this);
		this.editMenuPaste.setEnabled(false);
		menu.add(this.editMenuPaste);
		
		xMenu = res.getString("editMenuCut").split(":");
		this.editMenuCut = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.editMenuCut.setName(menuCodes.EDIT_CUT.ordinal() + "");
		this.editMenuCut.addActionListener(this);
		this.editMenuCut.setEnabled(false);
		menu.add(this.editMenuCut);
		
		menu.addSeparator();
		
		xMenu = res.getString("editMenuDelete").split(":");
		this.editMenuDelete = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.editMenuDelete.setName(menuCodes.EDIT_DELETE.ordinal() + "");
		this.editMenuDelete.addActionListener(this);
		this.editMenuDelete.setEnabled(false);
		menu.add(this.editMenuDelete);
		
		menu.addSeparator();
		
		xMenu = res.getString("editMenuInsertControl").split(":");
		this.editMenuInsertControl = new JMenu(xMenu[0]);
		this.editMenuInsertControl.setMnemonic(Integer.parseInt(xMenu[1]));
		this.editMenuInsertControl.setEnabled(false);
		menu.add(this.editMenuInsertControl);
		
		xMenu = res.getString("editMenuInsertLabel").split(":");
		this.editMenuInsertLabel = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.editMenuInsertLabel.setName(menuCodes.EDIT_INSERT_LABEL.ordinal() + "");
		this.editMenuInsertLabel.addActionListener(this);
		this.editMenuInsertControl.add(this.editMenuInsertLabel);
		
		xMenu = res.getString("editMenuInsertTextBox").split(":");
		this.editMenuInsertTextBox = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.editMenuInsertTextBox.setName(menuCodes.EDIT_INSERT_TEXTBOX.ordinal() + "");
		this.editMenuInsertTextBox.addActionListener(this);
		this.editMenuInsertControl.add(this.editMenuInsertTextBox);

		xMenu = res.getString("editMenuInsertButton").split(":");
		this.editMenuInsertButton = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.editMenuInsertButton.setName(menuCodes.EDIT_INSERT_BUTTON.ordinal() + "");
		this.editMenuInsertButton.addActionListener(this);
		this.editMenuInsertControl.add(this.editMenuInsertButton);
		
		xMenu = res.getString("editMenuInsertCheckBox").split(":");
		this.editMenuInsertCheckBox = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.editMenuInsertCheckBox.setName(menuCodes.EDIT_INSERT_CHECKBOX.ordinal() + "");
		this.editMenuInsertCheckBox.addActionListener(this);
		this.editMenuInsertControl.add(this.editMenuInsertCheckBox);
		
		menu.addSeparator();
		
		xMenu = res.getString("editMenuScreenProperties").split(":");
		menuItemScreenProps = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		menuItemScreenProps.setName(menuCodes.EDIT_SCREEN_PROPERTIES.ordinal() + "");
		menuItemScreenProps.addActionListener(this);
		menuItemScreenProps.setEnabled(temJanelaAberta());
		menu.add(menuItemScreenProps);	
		
		menuBar.add(menu);
		
		// PROJETO
		xMenu = res.getString("projectMenu").split(":");
		menu = new JMenu(xMenu[0]);
		menu.setMnemonic(Integer.parseInt(xMenu[1]));
		menuBar.add(menu);
		
		xMenu = res.getString("projectMenuRun").split(":");
		this.projectMenuRun = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.projectMenuRun.setName(menuCodes.PROJECT_RUN.ordinal() + "");
		this.projectMenuRun.addActionListener(this);
		this.projectMenuRun.setEnabled(false);
		menu.add(this.projectMenuRun);
		
		// PROJETO ANDROID
		
		xMenu = res.getString("projectMenuAndroid").split(":");
		projectMenuAndroid = new JMenu(xMenu[0]);
		projectMenuAndroid.setEnabled(false);
		menu.add(projectMenuAndroid);
		
		xMenu = res.getString("projectMenuAndroidSdk").split(":");
		this.projectMenuAndroidSdk = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.projectMenuAndroidSdk.setName(menuCodes.PROJECT_ANDROID_SDK.ordinal() + "");
		this.projectMenuAndroidSdk.addActionListener(this);
		projectMenuAndroid.add(this.projectMenuAndroidSdk);
		
		xMenu = res.getString("projectMenuAndroidCreateProject").split(":");
		this.projectMenuAndroidCreateProject = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.projectMenuAndroidCreateProject.setName(menuCodes.PROJECT_ANDROID_CREATE_PROJECT.ordinal() + "");
		this.projectMenuAndroidCreateProject.addActionListener(this);
		projectMenuAndroid.add(this.projectMenuAndroidCreateProject);
		
		xMenu = res.getString("projectMenuAndroidExecAVDManager").split(":");
		this.projectMenuAndroidExecAVDManager = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.projectMenuAndroidExecAVDManager.setName(menuCodes.PROJECT_ANDROID_AVD_MANAGER.ordinal() + "");
		this.projectMenuAndroidExecAVDManager.addActionListener(this);
		projectMenuAndroid.add(this.projectMenuAndroidExecAVDManager);
		
		xMenu = res.getString("projectMenuAndroidExecSDKManager").split(":");
		this.projectMenuAndroidExecSDKManager = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.projectMenuAndroidExecSDKManager.setName(menuCodes.PROJECT_ANDROID_SDK_MANAGER.ordinal() + "");
		this.projectMenuAndroidExecSDKManager.addActionListener(this);
		projectMenuAndroid.add(this.projectMenuAndroidExecSDKManager);
		
		xMenu = res.getString("projectMenuAndroidRunProject").split(":");
		this.projectMenuAndroidRunProject = new JMenuItem(xMenu[0],Integer.parseInt(xMenu[1]));
		this.projectMenuAndroidRunProject.setName(menuCodes.PROJECT_ANDROID_RUN_PROJECT.ordinal() + "");
		this.projectMenuAndroidRunProject.addActionListener(this);
		projectMenuAndroid.add(this.projectMenuAndroidRunProject);
		
		// FAKES
		
		
		
		menu = new JMenu("Ajuda");
		menu.addActionListener(this);
		menu.add(menu);		
		menuBar.add(menu);
		
		this.setJMenuBar(menuBar);
	}

	private boolean temJanelaAberta() {
		boolean resultCode = false;
		if (files.size() > 0 && currentSelectedUi != null) {
			resultCode = true;
		}
		return resultCode;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JMenuItem source = (JMenuItem)(e.getSource());
		menuCodes code = menuCodes.values()[Integer.parseInt(source.getName())];
		switch (code) {
		case FILE_NEW:
			createNewUI();
			break;
		case FILE_OPEN:
			openDialog();
			break;
		case FILE_SAVE:
			saveCurrentUi();
			break;
		case FILE_SAVE_AS:
			saveCurrentUiAs();
			break;
		case EXIT:
			if (terminate()) {
				System.exit(0);
			}
			break;
		case EDIT_COPY:
			this.lastCopy = this.selectedControl;
			lastCopyIsText = false;
			this.setEditMenuStatus();
			break;
		case EDIT_PASTE:
			int id = getControlNumber(selectedControl.getId());
			org.thecodebakers.aamo.editor.model.Element el = null;
			try {
				el = (Element) selectedControl.clone();
			} catch (CloneNotSupportedException e1) {
				e1.printStackTrace();
			}
			if (id > -1) {
				String msg = String.format(res.getString("controlAlreadyExists"), id);
				int resposta = JOptionPane.showConfirmDialog(selfRef, msg, 
						res.getString("titlePasteControl"), JOptionPane.YES_NO_OPTION);
				if (resposta == JOptionPane.YES_OPTION) {
					el.setId(id);
					currentSelectedUi.getScreen().getElements().add(el);
					addElement(currentSelectedUi.getFrame(),el);
					currentSelectedUi.getFrame().repaint();
				}
			}
			else {
				currentSelectedUi.getScreen().getElements().add(el);
				addElement(currentSelectedUi.getFrame(),el);
				currentSelectedUi.getFrame().repaint();
			}
			break;
		case EDIT_CUT:
			this.lastCopy = this.selectedControl;
			lastCopyIsText = false;
			currentSelectedUi.getFrame().remove(selectedControl.getComponent());
			currentSelectedUi.getScreen().getElements().remove(selectedControl);
			selectedControl.setComponent(null);
			currentSelectedUi.getFrame().repaint();
			aControlIsSelected = false;
			this.setEditMenuStatus();
			break;
		case EDIT_DELETE:
			currentSelectedUi.getFrame().remove(selectedControl.getComponent());
			currentSelectedUi.getScreen().getElements().remove(selectedControl);
			selectedControl = null;
			lastCopy = null;
			lastCopyIsText = false;
			currentSelectedUi.getFrame().repaint();
			aControlIsSelected = false;
			this.setEditMenuStatus();
			break;
		case EDIT_INSERT_LABEL:
			insertNewControl(ControlType.LABEL);
			break;
		case EDIT_INSERT_TEXTBOX:
			insertNewControl(ControlType.TEXTBOX);
			break;
		case EDIT_INSERT_BUTTON:
			insertNewControl(ControlType.BUTTON);
			break;
		case EDIT_INSERT_CHECKBOX:
			insertNewControl(ControlType.CHECKBOX);
			break;
		case EDIT_SCREEN_PROPERTIES:
			showScreenPropertiesDialog();
			break;
		case PROJECT_RUN:
			boolean salvo = true;
			if (files.size() > 0) {
				for (UiFile ui : files) {
					if (ui.isChanged()) {
						JOptionPane.showMessageDialog(this, res.getString("runPendingChanges"));
						salvo = false;
						break;
					}
				}
			}
			else {
				JOptionPane.showMessageDialog(this, res.getString("msgErrorNoApp"));
				salvo = false;
			}
					
			if (salvo) {
				File arqUI = new File(files.get(0).getPath());
				String dirApp = arqUI.getParent();
				DesktopRuntime.start(dirApp);	
			}
			
			break;
		}
			
	}

	private void insertNewControl (ControlType ct) {
		int id = getControlNumber(1);
		if (id < 0) {
			id = 1;
		}
		org.thecodebakers.aamo.editor.model.Element el = new org.thecodebakers.aamo.editor.model.Element();
		el.setId(id);
		el.setPercentTop(0);
		el.setPercentLeft(0);
		el.setPercentHeight(10);
		el.setPercentWidth(20);
		el.setType(ct);
		currentSelectedUi.getScreen().getElements().add(el);
		addElement(currentSelectedUi.getFrame(),el);
		currentSelectedUi.getFrame().repaint();
		desselectAll(currentSelectedUi);
		selectElement(el);
	}
	
	private void showScreenPropertiesDialog() {
		if (propertiesWindow == null) {
			propertiesWindow = new PropertiesWindow();
			propertiesWindow.setRes(res);
			propertiesWindow.setEditor(this);
		}
		propertiesWindow.setElement(null);
		propertiesWindow.setUi(currentSelectedUi);
		propertiesWindow.startWindow(true);		
	}

	private boolean terminate() {
		boolean terminar = true;
		for (UiFile ui : files) {
			if (ui.isChanged()) {
				if(hasPendingChanges()) {
					terminar = false;
					break;
				}
			}
		}
		return terminar;
		
	}

	private void saveCurrentUi() {
		if (desktop.getComponents().length > 0 && currentSelectedUi != null) {
			if (currentSelectedUi.isChanged()) {
				if (currentSelectedUi.getPath() != null && currentSelectedUi.getPath().length() > 0) {
					// faz um save
					try {
						XMLinterface.writeXML(currentSelectedUi.getPath(), currentSelectedUi.getScreen());
						
						if (currentSelectedUi.isChanged()) {
							String titulo = currentSelectedUi.getFrame().getTitle();
							titulo = titulo.substring(1);
							currentSelectedUi.getFrame().setTitle(titulo);
						}
						currentSelectedUi.setChanged(false);
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(this, res.getString("errorSavingXML") + ": " + ex.getLocalizedMessage());
					}
				}
				else {
					// nunca foi salvo, faz um "SAVE AS"
					saveCurrentUiAs();
				}
			}
		}
	}

	private void saveCurrentUiAs() {
		if (desktop.getComponents().length > 0 && currentSelectedUi != null) {
			Boolean old = UIManager.getBoolean("FileChooser.readOnly");  
			JFileChooser chooser = new JFileChooser(lastDirectory);
			chooser.setDialogTitle(res.getString("titleSaveDialog"));
			chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		    FileNameExtensionFilter filter = new FileNameExtensionFilter(
		        "UI files", "xml");
		    chooser.setFileFilter(filter);
		    int returnVal = chooser.showSaveDialog(this);
		    String name =  chooser.getSelectedFile().getPath() + File.separatorChar +
		    		((currentSelectedUi.getScreen().getUiid() == 1) ?
		    		"ui.xml" : "ui_" + currentSelectedUi.getScreen().getUiid() + ".xml");
		    
		    if(returnVal == JFileChooser.APPROVE_OPTION) {
			    lastDirectory = name;
			    if (new File(name).exists()) {
			    	int retVal = JOptionPane.showConfirmDialog(this, res.getString("fileAlreadyExists"), 
			    			res.getString("titleSaveDialog"), JOptionPane.YES_NO_OPTION);
			    	if (retVal == JOptionPane.NO_OPTION) {
			    		return;
			    	}
			    }
			    try {
					XMLinterface.writeXML(name, currentSelectedUi.getScreen());
					
					if (currentSelectedUi.isChanged()) {
						String titulo = currentSelectedUi.getFrame().getTitle();
						titulo = titulo.substring(1);
						currentSelectedUi.getFrame().setTitle(titulo);
					}
					currentSelectedUi.setChanged(false);
					currentSelectedUi.setPath(lastDirectory);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(this, res.getString("errorSavingXML") + ": " + ex.getLocalizedMessage());
				}
		    }

		}
		
	}

	private void openDialog() {
		JFileChooser chooser = new JFileChooser(lastDirectory);
		chooser.setDialogTitle(res.getString("titleOpenDialog"));
	    FileNameExtensionFilter filter = new FileNameExtensionFilter(
	        "UI files", "xml");
	    chooser.setFileFilter(filter);
	    int returnVal = chooser.showOpenDialog(this);
	    int fileNumber = -1;
	    if(returnVal == JFileChooser.APPROVE_OPTION) {;
		    lastDirectory = chooser.getSelectedFile().getPath();
		    if ((fileNumber = loadUIfile(chooser.getSelectedFile().getPath())) <= 0) {
		    	JOptionPane.showMessageDialog(this, res.getString("errorOpeningUI"),res.getString("titleOpenDialog"), JOptionPane.ERROR_MESSAGE);
		    }
	    }
	    this.enableFileMenu(true);
	}

	private int loadUIfile(String path) {
		int resultCode = -1;
		int pos = path.lastIndexOf("\\");
		if (pos < 0) {
			resultCode = -2;
		}
		else {
			String name = path.substring(pos+1);
			int posHifen = name.indexOf('_');
			if (posHifen >= 0) {
				// is a ui_n file
				int number = validadeUInumber(name);
				if (number < 0) {
					resultCode = -2;
				}
				else {
					// OK load the file
					resultCode = number;
					UiFile uiFile = new UiFile();
					if (!loadFile(path, number, uiFile)) {
						resultCode = -10;
					}
					else {
						files.add(uiFile);
						createAndShow(this.screenWidth, 
									  this.screenHeight,
									  number,
									  uiFile);
						uiFile.setNumber(number);
					}
				}
			}
			else {
				// is a ui.xml file
				if (name.equals("ui.xml")) {
					// OK load the file
					resultCode = 1;
					UiFile uiFile = new UiFile();
					if (!loadFile(path,1, uiFile)) {
						resultCode = -10;
					}
					else {
						files.add(uiFile);
						createAndShow(this.screenWidth, 
									  this.screenHeight,
									  1,
									  uiFile);
					}
				}
				else {
					resultCode = -3;
				}
			}
		}
		return resultCode;
	}

	private boolean loadFile(String path, int number, UiFile uiFile) {
		boolean returnCode = true;
		try {
			uiFile.setScreen(XMLinterface.readXML(path));
			uiFile.setPath(path);
			
		} catch (Exception e) {
			returnCode = false;
		}
		return returnCode;
	}

	private int validadeUInumber(String name) {
		int resultCode = -1;
		try {
			int posNumber = name.indexOf('.');
			int fNumber = Integer.parseInt(name.substring(3, posNumber));
			if (name.equals("ui_" + fNumber + ".xml")) {
				resultCode = fNumber;
			}
			else {
				resultCode = -5;
			}
		}
		catch (NumberFormatException nfe) {
			resultCode = -4;
		}
		return resultCode;
	}

	private void createNewUI() {
		selectScreenSize();
		final JDialog dialogo = new JDialog(this, true);
		dialogo.setTitle(res.getString("titleUiDialog"));
		dialogo.setLayout(new BoxLayout(dialogo.getContentPane(), BoxLayout.Y_AXIS));
		JPanel pWork = new JPanel();
		final JTextField textWidth = new JTextField(20);
		final JTextField textHeight = new JTextField(20);
		final SpinnerNumberModel spinModel = new SpinnerNumberModel(1, 1, 100, 1);
		final JSpinner spinUI = new JSpinner(spinModel);
		final JLabel errorMSG = new JLabel("");
		if (this.screenHeight == 0) {
			// Other device...
			JLabel lab1 = new JLabel(res.getString("labWidth"));
			textWidth.addKeyListener(this);
			pWork.add(lab1);
			pWork.add(textWidth);
			JLabel lab2 = new JLabel(res.getString("labHeight"));
			textHeight.addKeyListener(this);
			pWork.add(lab2);
			pWork.add(textHeight);
			dialogo.add(pWork);
		}
		pWork = new JPanel();
		JLabel lab2 = new JLabel(res.getString("labUiid"));
		spinUI.setEditor(new JSpinner.NumberEditor(spinUI,"###"));
		JFormattedTextField txt = ((JSpinner.NumberEditor) spinUI.getEditor()).getTextField();
		((NumberFormatter) txt.getFormatter()).setAllowsInvalid(false);
		pWork.add(lab2);
		pWork.add(spinUI);
		dialogo.add(pWork);
		
		pWork = new JPanel();
		JButton btnOK = new JButton(res.getString("ok"));
		btnOK.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (screenHeight == 0) {
					if ((textWidth.getText() == null || 
							textWidth.getText().length() == 0) ||
							(textHeight.getText() == null || 
							textHeight.getText().length() == 0) ||
							(Integer.parseInt(textWidth.getText()) <= 0 || 
							Integer.parseInt(textHeight.getText()) <=0)) {
							errorMSG.setText(res.getString("invalidMeasure"));
					}
					else {
						UiFile uiFile = new UiFile();
						createScreen(uiFile, spinModel.getNumber().intValue());
						files.add(uiFile);
						createAndShow(Integer.parseInt(textWidth.getText()),
								Integer.parseInt(textHeight.getText()), 
								spinModel.getNumber().intValue(), uiFile);
						currentSelectedUi = uiFile;
						setEditMenuStatus();
						uiFile.setNumber(spinModel.getNumber().intValue());
						uiFile.setChanged(true);
						uiFile.getFrame().setTitle("*" + uiFile.getFrame().getTitle());
						menuItemScreenProps.setEnabled(true);
						dialogo.setVisible(false);
					}
				}
				else {
					UiFile uiFile = new UiFile();
					files.add(uiFile);
					createScreen(uiFile, spinModel.getNumber().intValue());
					createAndShow(-1,
							-1, 
							spinModel.getNumber().intValue(), uiFile);
					currentSelectedUi = uiFile;
					setEditMenuStatus();
					uiFile.setNumber(spinModel.getNumber().intValue());
					uiFile.setChanged(true);
					uiFile.getFrame().setTitle("*" + uiFile.getFrame().getTitle());
					menuItemScreenProps.setEnabled(true);
					dialogo.setVisible(false);
				}
			}
		});
		
		JButton btnCancel = new JButton(res.getString("cancel"));
		btnCancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dialogo.setVisible(false);
				
			}
			
		});
		
		pWork.add(btnOK);
		pWork.add(btnCancel);
		dialogo.add(pWork);
		
		dialogo.add(errorMSG);
		
		dialogo.setSize(500, 300);
		
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		int w = dialogo.getSize().width;
		int h = dialogo.getSize().height;
		int x = (dim.width-w)/2;
		int y = (dim.height-h)/2;
		dialogo.setLocation(x, y);
		dialogo.setVisible(true);
		enableFileMenu(true);
	}


	private void enableFileMenu(boolean b) {
		this.fileMenuSave.setEnabled(b);
		this.fileMenuSaveAs.setEnabled(b);
		this.projectMenuRun.setEnabled(b);
		this.projectMenuAndroid.setEnabled(b);
	}

	protected void createScreen(UiFile uiFile, int uiid) {
		Screen screen = new Screen();
		screen.setElements(new ArrayList<org.thecodebakers.aamo.editor.model.Element>());
		screen.setTitle(null);
		screen.setUiid(uiid);
		screen.setVersion(AAMO_VERSION);
		uiFile.setScreen(screen);
		uiFile.setDevSelect(currentDeviceIndex);
	}

	protected void createAndShow(int tWidth, int tHeight, int uiid, UiFile uiFile) {
		if (tWidth > 0 && tHeight > 0) {
			this.screenWidth = tWidth;
			this.screenHeight = tHeight;			
		}
		JInternalFrame newFrame = redimScreen(uiid);
		uiFile.setFrame(newFrame);
		uiFile.setScreenHeight(this.screenHeight);
		uiFile.setScreenWidth(this.screenWidth);
		uiFile.setNumber(uiid);
		currentSelectedUi = uiFile;
		this.setEditMenuStatus();
		for (org.thecodebakers.aamo.editor.model.Element el : uiFile.getScreen().getElements()) {
			addElement(uiFile.getFrame(),el);
		}
		menuItemScreenProps.setEnabled(true);
	}


	private void addElement(JInternalFrame frame, Element el) {
		frame.setLayout(null);
		float top = (float) ((el.getPercentTop() / 100) * this.screenHeight);
		float left = (float) ((el.getPercentLeft() / 100) * this.screenWidth);
		float width = (float) ((el.getPercentWidth() / 100) * this.screenWidth);
		float height = (float) ((el.getPercentHeight() / 100) * this.screenHeight);
		JLabel label1 = new JLabel();
        label1.setName(el.getId() + "");
        label1.addMouseListener(this);
        el.setEvents(commonEvents[el.getType().ordinal()]);
		switch (el.getType()) {
		case LABEL:
			label1.setBounds((int) left, (int) top, (int) width, (int) height);
			label1.setIcon(new ColorIcon((int)width, (int)height, el.getType()));
			if (el.getText() != null && el.getText().length() > 0) {
				label1.setText(el.getText());
			}
			label1.setHorizontalTextPosition(JLabel.CENTER);
	        label1.setVerticalTextPosition(JLabel.CENTER);
			break;
		case TEXTBOX:
			label1.setBounds((int) left, (int) top, (int) width, (int) height);
			label1.setIcon(new ColorIcon((int)width, (int)height, el.getType()));
			if (el.getText() != null && el.getText().length() > 0) {
				label1.setText(el.getText());
			}
			label1.setHorizontalTextPosition(JLabel.CENTER);
	        label1.setVerticalTextPosition(JLabel.CENTER);
			break;
		case BUTTON:
			label1.setBounds((int) left, (int) top, (int) width, (int) height);
			label1.setIcon(new ColorIcon((int)width, (int)height, el.getType()));
			if (el.getText() != null && el.getText().length() > 0) {
				label1.setText(el.getText());
			}
			label1.setHorizontalTextPosition(JLabel.CENTER);
	        label1.setVerticalTextPosition(JLabel.CENTER);
			break;
		case CHECKBOX:
			width = (float) ((el.getPercentWidth() / 100) * this.screenHeight);
			label1.setIcon(new ColorIcon((int)width, (int)height, el.getType()));
			label1.setBounds((int) left, (int) top, (int) width, (int) height);
			break;

		case LISTBOX:
			label1.setBounds((int) left, (int) top, (int) width, (int) height);
			label1.setIcon(new ColorIcon((int)width, (int)height, el.getType()));
			
			break;
		case WEBBOX:
			label1.setBounds((int) left, (int) top, (int) width, (int) height);
			label1.setIcon(new ColorIcon((int)width, (int)height, el.getType()));

			break;
		case IMAGEBOX:
			label1.setBounds((int) left, (int) top, (int) width, (int) height);
			label1.setIcon(new ColorIcon((int)width, (int)height, el.getType()));

			break;
		}
		el.setComponent(label1);
		frame.add(label1);
		frame.repaint();
	}

	private boolean hasPendingChanges() {
		boolean returnCode = false;

		int resposta = JOptionPane.showConfirmDialog(this, 
											res.getString("pendingChanges"), 
											res.getString("attention"), 
											JOptionPane.YES_NO_OPTION);
		if (resposta == JOptionPane.YES_OPTION) {
			returnCode = false;
		}
		else {
			returnCode = true;
		}
		return returnCode;
	}
	
	private void prepareDevicesList() {
		devices = new String [][]  {
				res.getString("sizeDefault").split(":"),
				res.getString("sizeIPHONE4").split(":"),
				res.getString("sizeIPHONE3GS").split(":"),
				res.getString("sizeIPAD2").split(":"),
				res.getString("sizeIPAD3").split(":"),
				res.getString("sizeGalaxTab").split(":"),
				res.getString("sizeXoom2").split(":"),
				res.getString("sizeXoom2Media").split(":"),
				res.getString("sizeGalaxyS3").split(":"),
				res.getString("sizeGalaxyS2").split(":"),
				res.getString("sizeAtrix").split(":"),
				res.getString("sizeXperiaS").split(":"),
				res.getString("sizeOther").split(":")
		};
		deviceName = new String[devices.length];
		for (int x=0; x < devices.length; x++) {
			deviceName[x] = devices[x][0];
		}
	}
	
	public void selectScreenSize() {
		currentDeviceIndex = -99;
		String s = (String) JOptionPane.showInputDialog(
                this,
                res.getString("selectScreenSize"),
                res.getString("titleDeviceSelect"),
                JOptionPane.PLAIN_MESSAGE,
                null,
                deviceName,
                deviceName[0]);
                
		if ((s != null) && (s.length() > 0)) {
			for (int x=0; x < devices.length; x++) {
				if (s.equalsIgnoreCase(devices[x][0])) {
					this.screenWidth = Integer.parseInt(devices[x][1]);
					this.screenHeight = Integer.parseInt(devices[x][2]);
					currentDeviceIndex = x;
					break;
				}
			}
		}
		else {
			currentDeviceIndex = 0;
			this.screenWidth = Integer.parseInt(devices[0][1]);
			this.screenHeight = Integer.parseInt(devices[0][2]);
		}

	}

	private JInternalFrame redimScreen(int uiid) {

		if (desktop == null) {
			desktop = new JScrollableDesktopPane();
		}
		JInternalFrame frame = new BaseInternalFrame();
		frame.setSize(this.screenWidth,this.screenHeight);
	    frame.setVisible(true);
	    frame.setResizable(false);
	    frame.setClosable(true);
	    frame.setTitle("UI " + uiid);
	    frame.setName(uiid + "");
	    frame.setFocusable(true);
	    frame.addFocusListener(this);
	    frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	    frame.addInternalFrameListener(new javax.swing.event.InternalFrameAdapter() {
	          public void internalFrameClosing(InternalFrameEvent e) {
	            closeFrame(e.getInternalFrame());
	          }
	        });
	    desktop.add(frame);
	    
	    
	    this.setContentPane(desktop);
		return frame;
		
	}

	@Override
	public void keyPressed(KeyEvent arg0) {

		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		
		
	}

	@Override
	public void keyTyped(KeyEvent e) {

        char c = e.getKeyChar();
        if (!((c >= '0') && (c <= '9') ||
           (c == KeyEvent.VK_BACK_SPACE) ||
           (c == KeyEvent.VK_DELETE))) {
          getToolkit().beep();
          e.consume();
        }
     }

	@Override
	public void mouseClicked(MouseEvent e) {
		// Se clicou em algum controle, o name � o nome do controle, caso contr�rio � zero
		this.aControlIsSelected = false;
		int elementId = 0;
		if (e.getComponent().getName() != null) {
			try {
				elementId = Integer.parseInt(e.getComponent().getName());
			}
			catch (Exception nfe) {
				elementId = 0;
			}
		}
		if (elementId > 0) {
			desselectAll(currentSelectedUi);
			for (org.thecodebakers.aamo.editor.model.Element el : currentSelectedUi.getScreen().getElements()) {
				JLabel lbl1 = (JLabel) el.getComponent();
				if (elementId == el.getId()) {
					lbl1.setBorder(new LineBorder(Color.red,2));
					el.setSelected(true);
					controlInFocus(el);			
				}
				else {
					lbl1.setBorder(null);
				}
			}
		}
		
	}

	private void controlInFocus(Element el) {
		if (propertiesWindow == null) {
			propertiesWindow = new PropertiesWindow();
			propertiesWindow.setRes(res);
			propertiesWindow.setEditor(this);
		}
		propertiesWindow.setElement(el);
		propertiesWindow.setUi(currentSelectedUi);
		propertiesWindow.startWindow(false);
		this.selectedControl = el;
		this.aControlIsSelected = true;
		this.setEditMenuStatus();
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void focusGained(FocusEvent fe) {
		int frameId = 0;
		if (fe.getComponent().getName() != null) {
			try {
				frameId = Integer.parseInt(fe.getComponent().getName());
			}
			catch (Exception nfe) {
				frameId = 0;
			}
		}
		if (frameId > 0) {
			for (UiFile uiFile : files) {
				if (uiFile.getScreen().getUiid() == frameId) {
					if (uiFile.getFrame() == fe.getComponent()) {
						if (currentSelectedUi != uiFile) {
							desselectAll(currentSelectedUi);
						}
						currentSelectedUi = uiFile;
						this.setEditMenuStatus();
						break;
					}
				}
			}
		}
		
	}

	@Override
	public void focusLost(FocusEvent fe) {

		
	}
	public void closeFrame(JInternalFrame frame) {
		int frameUIID = Integer.parseInt(frame.getName());
		UiFile uiFile = null;
		for (UiFile ui: files) {
			if (ui.getScreen().getUiid() == frameUIID) {
				if (ui.getFrame() == frame) {
					if (ui.isChanged()) {
						if(hasPendingChanges()) {
							return;
						}
					}
					uiFile = ui;
					break;
				}
			}
		}
		try {
			if (propertiesWindow != null && propertiesWindow.isVisible()) {
				if (propertiesWindow.getUi().getScreen().getUiid() == frameUIID &&
						propertiesWindow.getUi().getFrame() == frame) {
					propertiesWindow.setVisible(false);
				}
			}
			desktop.remove(frame);
			frame.setVisible(false);
			frame.setClosed(true);
			files.remove(uiFile);
			menuItemScreenProps.setEnabled(temJanelaAberta());
			currentSelectedUi = null;
			this.aControlIsSelected = false;
			this.setEditMenuStatus();
			if (this.files.size() == 0) {
				this.enableFileMenu(false);
			}
		} catch (PropertyVetoException e) {

		} catch (StackOverflowError soe) {
			
		}
	}

	private void desselectAll(UiFile uiFile) {
		if (uiFile != null) {
			for (org.thecodebakers.aamo.editor.model.Element el :
				uiFile.getScreen().getElements()) {
				el.getComponent().setBorder(null);
				el.setSelected(false);
			}			
		}

		this.aControlIsSelected = false;
		this.setEditMenuStatus();
	}

	public void moveControl(int vertical, int horizontal) {
		for (org.thecodebakers.aamo.editor.model.Element el : currentSelectedUi.getScreen().getElements()) {
			if (el.isSelected()) {
				Rectangle rect = el.getComponent().getBounds();
				rect.x += horizontal;
				rect.y += vertical;
				el.getComponent().setBounds(rect);
				el.setPercentLeft((int) Math.round(((double)rect.x / (double)currentSelectedUi.getScreenWidth()) * 100.0d));
				el.setPercentTop((int) Math.round(((double)rect.y / (double)currentSelectedUi.getScreenHeight()) * 100.0d));
				break;
			}
		}
	}
	
	public void resizeControl(int vertical, int horizontal) {
		for (org.thecodebakers.aamo.editor.model.Element el : currentSelectedUi.getScreen().getElements()) {
			if (el.isSelected()) {
				Rectangle rect = el.getComponent().getBounds();
				if (el.getType() != ControlType.CHECKBOX) {
					if (vertical > 0) {
						rect.height = (int) Math.round(vertical / 100.0d * (double) currentSelectedUi.getScreenHeight());
						el.setPercentHeight((int) Math.round(((double)rect.height / (double)currentSelectedUi.getScreenHeight()) * 100.0d));
					}
					if (horizontal > 0) {
						rect.width = (int) Math.round(horizontal / 100.0d * (double) currentSelectedUi.getScreenWidth());
						el.setPercentWidth((int) Math.round(((double)rect.width / (double)currentSelectedUi.getScreenWidth()) * 100.0d));
					}
				}
				else {
					if (vertical > 0) {
						rect.height = (int) Math.round(vertical / 100.0d * (double) currentSelectedUi.getScreenHeight());
						el.setPercentHeight((int) Math.round(((double)rect.height / (double)currentSelectedUi.getScreenHeight()) * 100.0d));
					}
					if (horizontal > 0) {
						rect.width = (int) Math.round(vertical / 100.0d * (double) currentSelectedUi.getScreenHeight());
						el.setPercentWidth((int) Math.round(((double)rect.height / (double)currentSelectedUi.getScreenHeight()) * 100.0d));
					}
					
				}
				el.getComponent().setBounds(rect);
				((JLabel) el.getComponent()).setIcon(new ColorIcon((int)rect.width, (int)rect.height, el.getType()));
				break;
			}
		}		
	}
	
	public int getScreenTop() {
		return screenTop;
	}

	public void setScreenTop(int screenTop) {
		this.screenTop = screenTop;
	}

	public int getScreenLeft() {
		return screenLeft;
	}

	public void setScreenLeft(int screenLeft) {
		this.screenLeft = screenLeft;
	}

	public int getScreenWidth() {
		return screenWidth;
	}

	public void setScreenWidth(int screenWidth) {
		this.screenWidth = screenWidth;
	}

	public int getScreenHeight() {
		return screenHeight;
	}

	public void setScreenHeight(int screenHeight) {
		this.screenHeight = screenHeight;
	}

	public void changeSelectedScreen() {
		JInternalFrame newFrame = currentSelectedUi.getFrame();
		newFrame.setVisible(false);
		desktop.remove(newFrame);
		newFrame = null;
		newFrame = redimScreen(currentSelectedUi.getScreen().getUiid());
		currentSelectedUi.setFrame(newFrame);
		currentSelectedUi.setDevSelect(currentDeviceIndex);
		currentSelectedUi.setScreenHeight(this.screenHeight);
		currentSelectedUi.setScreenWidth(this.screenWidth);
		for (org.thecodebakers.aamo.editor.model.Element el : currentSelectedUi.getScreen().getElements()) {
			addElement(currentSelectedUi.getFrame(),el);
		}
		this.setEditMenuStatus();
	}
	
	public void setEditMenuStatus() {
		if (currentSelectedUi != null && files.size() != 0) {
			this.editMenuInsertControl.setEnabled(true);
			if (this.lastCopy != null && (!this.lastCopyIsText)) {
				this.editMenuPaste.setEnabled(true);
			}
			else {
				this.editMenuPaste.setEnabled(false);
			}
			if (this.aControlIsSelected) {
				this.editMenuCopy.setEnabled(true);
				this.editMenuCut.setEnabled(true);
				this.editMenuDelete.setEnabled(true);
			}
			else {
				this.editMenuCopy.setEnabled(false);
				this.editMenuCut.setEnabled(false);
				this.editMenuDelete.setEnabled(false);
			}
			
		}
		else {
			this.editMenuInsertControl.setEnabled(false);
			this.editMenuCopy.setEnabled(false);
			this.editMenuCut.setEnabled(false);
			this.editMenuDelete.setEnabled(false);
		}
	}
	
	public int getControlNumber(int number) {
		// Verifica se j� existe um controle com o mesmo n�mero.
		// Se n�o existir, retorna -1, caso contr�rio, retorna o pr�ximo n�mero dispon�vel.
		int maior = 0;
		boolean achou = false;
		for (org.thecodebakers.aamo.editor.model.Element el : currentSelectedUi.getScreen().getElements()) {
			if (el.getId() >= maior) {
				maior = el.getId();
			}
			if (number == el.getId()) {
				achou = true;
			}
		}
		
		return (achou ? maior + 1 : -1);
	}
	
	private void selectElement(org.thecodebakers.aamo.editor.model.Element el) {
		JLabel lbl1 = (JLabel) el.getComponent();
		lbl1.setBorder(new LineBorder(Color.red,2));
		el.setSelected(true);
		controlInFocus(el);	
	}
}

