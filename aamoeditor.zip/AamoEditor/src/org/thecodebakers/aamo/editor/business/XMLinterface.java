package org.thecodebakers.aamo.editor.business;

import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.thecodebakers.aamo.editor.model.Constants.ControlType;
import org.thecodebakers.aamo.editor.model.Screen;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XMLinterface {
	
	public static Screen readXML(String path) throws SAXException, IOException, ParserConfigurationException {
		Screen screen = new Screen();
		File fXmlFile = new File(path);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		
		InputStream is = new FileInputStream(path);  
		Reader reader = new InputStreamReader(is, "UTF-8"); // look up which encoding your file should have  
		InputSource source = new InputSource(reader);  
		Document doc = dBuilder.parse(source);  
		
		
		//Document doc = dBuilder.parse(fXmlFile);
		doc.getDocumentElement().normalize();
		Element ui = doc.getDocumentElement();
		
		screen.setUiid(Integer.parseInt(getTagValue("uiid", ui)));
		screen.setTitle(getTagValue("title", ui));
		screen.setVersion(Double.parseDouble(getTagValue("version", ui)));
		screen.setOnLoadScript(getTagValue("onLoadScript", ui));
		screen.setOnEndScript(getTagValue("onEndScript", ui));
		screen.setOnLeaveScript(getTagValue("onLeaveScript", ui));
		screen.setOnBackScript(getTagValue("onBackScript", ui));
		screen.setOnMenuSelected(getTagValue("onMenuSelected", ui));
		screen.setBackgroundColor(getTagValue("backgroundColor", ui));

		NodeList nos = ui.getElementsByTagName("menu");
		if (nos != null && nos.getLength() > 0) {
			screen.setMenuOptions(new ArrayList<String>());
			NodeList itensMenu = ((Element)nos.item(0)).getElementsByTagName("option");
			if (itensMenu != null && itensMenu.getLength() > 0) {
				for (int x = 0; x < itensMenu.getLength(); x++) {
					if (itensMenu.item(x).getTextContent() != null) {
						screen.getMenuOptions().add(itensMenu.item(x).getTextContent());
					}
				}
			}
		}		
		
		// Agora pegamos os elementos
		
		NodeList elementList = ui.getElementsByTagName("element");
		
		for (int x = 0; x < elementList.getLength(); x++) {
			Node nNode = elementList.item(x);
			org.thecodebakers.aamo.editor.model.Element el = new org.thecodebakers.aamo.editor.model.Element();
			screen.getElements().add(el);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				  Element eElement = (Element) nNode;
				  String valor = null;
				  el.setId(Integer.parseInt(getTagValue("id", eElement)));
				  valor = getTagValue("checked", eElement);
				  el.setChecked(valor == null ? false : Integer.parseInt(valor) != 0);
				  valor = getTagValue("onChangeScript", eElement);
				  el.setOnChangeScript(valor);
				  valor = getTagValue("onClickScript", eElement);
				  el.setOnClickScript(valor);
				  valor = getTagValue("percentHeight", eElement);
				  el.setPercentHeight(valor == null ? 0 : Double.parseDouble(valor));
				  valor = getTagValue("percentLeft", eElement);
				  el.setPercentLeft(valor == null ? 0 : Double.parseDouble(valor));
				  valor = getTagValue("percentTop", eElement);
				  el.setPercentTop(valor == null ? 0 : Double.parseDouble(valor));
				  valor = getTagValue("percentWidth", eElement);
				  el.setPercentWidth(valor == null ? 0 : Double.parseDouble(valor));
				  el.setText(getTagValue("text", eElement));
				  ControlType ct = ControlType.values()[Integer.parseInt(getTagValue("type", eElement))];
				  el.setType(ct);

				  el.setUrl(getTagValue("url", eElement));
				  el.setOnCompleteScript(getTagValue("onCompleteScript", eElement));
				  el.setOnElementSelected(getTagValue("onElementSelected", eElement));
				  el.setPicture(getTagValue("picture", eElement));
				  valor = getTagValue("stretch", eElement);
				  el.setStretch(valor == null ? false : Integer.parseInt(valor) != 0);
				  el.setListElements(new ArrayList<String>());
			 }
		}
		
		return screen;
	}
	
	public static boolean writeXML(String path, Screen screen) throws ParserConfigurationException, TransformerException {
		boolean returnCode = true;
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
 
		// root elements
		Document doc = docBuilder.newDocument();
		
		Element rootElement = doc.createElement("ui");
		doc.appendChild(rootElement);
		
		ResourceBundle res = ResourceBundle.getBundle("org.thecodebakers.aamo.editor.resources.editor");
		
		Comment simpleComment = doc.createComment(" --- CREATED WITH MACHINAPP IDE V.: " + res.getString("version") + " --- ");
		rootElement.appendChild(simpleComment);
		
		// UUID
		Element el = doc.createElement("uiid");
		el.appendChild(doc.createTextNode(screen.getUiid() + ""));
		rootElement.appendChild(el);
		
		//TITLE
		el = doc.createElement("title");
		if (screen.getTitle() != null && screen.getTitle().length() > 0) {
			el.appendChild(doc.createTextNode(screen.getTitle()));
		}
		rootElement.appendChild(el);
		
		//VERSION
		el = doc.createElement("version");
		el.appendChild(doc.createTextNode(screen.getVersion() + ""));
		rootElement.appendChild(el);
		
		//ON LOAD SCRIPT
		el = doc.createElement("onLoadScript");
		if (screen.getOnLoadScript() != null && screen.getOnLoadScript().length() > 0) {
			el.appendChild(doc.createTextNode(screen.getOnLoadScript()));
		}
		rootElement.appendChild(el);
		
		
		//ON END SCRIPT
		el = doc.createElement("onEndScript");
		if (screen.getOnEndScript() != null && screen.getOnEndScript().length() > 0) {
			el.appendChild(doc.createTextNode(screen.getOnEndScript()));
		}
		rootElement.appendChild(el);
		
		//ON LEAVE SCRIPT
		el = doc.createElement("onLeaveScript");
		if (screen.getOnLeaveScript() != null && screen.getOnLeaveScript().length() > 0) {
			el.appendChild(doc.createTextNode(screen.getOnLeaveScript()));
		}
		rootElement.appendChild(el);
		
		//ON BACK SCRIPT
		el = doc.createElement("onBackScript");
		if (screen.getOnBackScript() != null && screen.getOnBackScript().length() > 0) {
			el.appendChild(doc.createTextNode(screen.getOnBackScript()));
		}
		//ON MENU SELECTED
		el = doc.createElement("onMenuSelected");
		if (screen.getOnMenuSelected() != null && screen.getOnMenuSelected().length() > 0) {
			el.appendChild(doc.createTextNode(screen.getOnMenuSelected()));
		}
		rootElement.appendChild(el);
		
		//BACKGROUND COLOR
		el = doc.createElement("backgroundColor");
		if (screen.getBackgroundColor() != null && screen.getBackgroundColor().length() > 0) {
			el.appendChild(doc.createTextNode(screen.getBackgroundColor()));
		}
		rootElement.appendChild(el);
		
		// MENU
		if (screen.getMenuOptions() != null && screen.getMenuOptions().size() > 0) {
			el = doc.createElement("menu");
			rootElement.appendChild(el);
			for (String option : screen.getMenuOptions()) {
				Element menuOption = doc.createElement("option");
				menuOption.appendChild(doc.createTextNode(option));
				el.appendChild(menuOption);
			}
		}
		
		
		// Agora vai gravar os "ELEMENTS"
		
		for (org.thecodebakers.aamo.editor.model.Element ele : screen.getElements()) {
			Element ele1 = doc.createElement("element");
			rootElement.appendChild(ele1);
			
			//ID
			Element ele2 = doc.createElement("id");
			ele2.appendChild(doc.createTextNode(ele.getId() + ""));
			ele1.appendChild(ele2);
			
			//CHECKED
			ele2 = doc.createElement("checked");
			ele2.appendChild(doc.createTextNode(ele.isChecked() ? "1" : "0"));
			ele1.appendChild(ele2);
			
			//ON CHANGE SCRIPT
			ele2 = doc.createElement("onChangeScript");
			if (ele.getOnChangeScript() != null && ele.getOnChangeScript().length() > 0) {
				ele2.appendChild(doc.createTextNode(ele.getOnChangeScript()));
			}
			ele1.appendChild(ele2);
			
			//ON CLICK SCRIPT
			ele2 = doc.createElement("onClickScript");
			if (ele.getOnClickScript() != null && ele.getOnClickScript().length() > 0) {
				ele2.appendChild(doc.createTextNode(ele.getOnClickScript()));
			}
			ele1.appendChild(ele2);
			
			//PERCENT HEIGHT
			ele2 = doc.createElement("percentHeight");
			ele2.appendChild(doc.createTextNode(ele.getPercentHeight() + ""));
			ele1.appendChild(ele2);
			
			//PERCENT LEFT
			ele2 = doc.createElement("percentLeft");
			ele2.appendChild(doc.createTextNode(ele.getPercentLeft() + ""));
			ele1.appendChild(ele2);
			
			//PERCENT TOP
			ele2 = doc.createElement("percentTop");
			ele2.appendChild(doc.createTextNode(ele.getPercentTop() + ""));
			ele1.appendChild(ele2);
			
			//PERCENT WIDTH
			ele2 = doc.createElement("percentWidth");
			ele2.appendChild(doc.createTextNode(ele.getPercentWidth() + ""));
			ele1.appendChild(ele2);
			
			//TEXT
			ele2 = doc.createElement("text");
			if (ele.getText() != null && ele.getText().length() > 0) {
				ele2.appendChild(doc.createTextNode(ele.getText()));
			}
			ele1.appendChild(ele2);
			
			//TYPE
			ele2 = doc.createElement("type");
			ele2.appendChild(doc.createTextNode(ele.getType().ordinal() + ""));
			ele1.appendChild(ele2);

			//URL
			if (ele.getUrl() != null && ele.getUrl().length() > 0) {
				ele2 = doc.createElement("url");
				ele2.appendChild(doc.createTextNode(ele.getUrl()));
			}
			ele1.appendChild(ele2);

			//onCompleteScript
			if (ele.getOnCompleteScript() != null && ele.getOnCompleteScript().length() > 0) {
				ele2 = doc.createElement("onCompleteScript");
				ele2.appendChild(doc.createTextNode(ele.getOnCompleteScript()));
			}
			ele1.appendChild(ele2);		
			
			//onElementSelected
			if (ele.getOnElementSelected() != null && ele.getOnElementSelected().length() > 0) {
				ele2 = doc.createElement("onElementSelected");
				ele2.appendChild(doc.createTextNode(ele.getOnElementSelected()));
			}
			ele1.appendChild(ele2);
			
			//picture
			if (ele.getPicture() != null && ele.getPicture().length() > 0) {
				ele2 = doc.createElement("picture");
				ele2.appendChild(doc.createTextNode(ele.getPicture()));
			}
			ele1.appendChild(ele2);	
			
			//stretch
			ele2 = doc.createElement("stretch");
			ele2.appendChild(doc.createTextNode(ele.isStretch() ? "1" : "0"));
			ele1.appendChild(ele2);				
			
		}
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(path));
		transformer.transform(source, result);
		return returnCode;
	}
	
	 private static String getTagValue(String sTag, Element eElement) {
		 NodeList nlList = null;
		 Node nValue = null;
		 try {
				nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
				nValue = (Node) nlList.item(0);
		 }
		 catch (Exception ex) {
			 
		 }
		 
		return nValue == null ? null : nValue.getNodeValue();
	}
}
