package org.thecodebakers.aamo.editor.test;

import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.thecodebakers.aamo.editor.model.Constants.ControlType;
import org.thecodebakers.aamo.editor.ui.ColorIcon;



public class TestIcons extends JPanel {

	
	
	public TestIcons() {
		JLabel label1 = new JLabel(new ColorIcon(50, 20, ControlType.LABEL));
        label1.setText( "Label" );
        label1.setHorizontalTextPosition(JLabel.CENTER);
        label1.setVerticalTextPosition(JLabel.CENTER);
        add(label1);
        
        JLabel label2 = new JLabel(new ColorIcon(50, 30, ControlType.BUTTON));
        label2.setText( "OK" );
        label2.setHorizontalTextPosition(JLabel.CENTER);
        label2.setVerticalTextPosition(JLabel.CENTER);
        add(label2);
    
        JLabel label3 = new JLabel(new ColorIcon(60, 30, ControlType.TEXTBOX));
        label3.setText( "TextBOX" );
        label3.setHorizontalTextPosition(JLabel.CENTER);
        label3.setVerticalTextPosition(JLabel.CENTER);
        add(label3);
        
        JLabel label4 = new JLabel(new ColorIcon(0, 0, ControlType.CHECKBOX));
        add(label4);
        
        
        
        
	}
	
	public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                createAndShowUI();
            }

        });
	}

	protected static void createAndShowUI() {
        JFrame frame = new JFrame("Teste");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        TestIcons t = new TestIcons();
        frame.setLayout(new FlowLayout());
        frame.add(new TestIcons());
        t.doLayout();
        frame.pack();
        frame.setLocationRelativeTo( null );
        frame.setVisible( true );
       
	}

}
