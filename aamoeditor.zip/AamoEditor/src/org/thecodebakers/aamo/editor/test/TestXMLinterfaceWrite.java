package org.thecodebakers.aamo.editor.test;

import static org.junit.Assert.*;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.junit.Test;
import org.thecodebakers.aamo.editor.business.XMLinterface;
import org.thecodebakers.aamo.editor.model.Screen;
import org.xml.sax.SAXException;

public class TestXMLinterfaceWrite {

	@Test
	public void testWriteXML() throws SAXException, IOException, ParserConfigurationException, TransformerException {
		String path = "C:/projetos/WS/aamoeditor/ui.xml";
		Screen screen = XMLinterface.readXML(path);
		assertTrue(screen.getElements().size() > 0);
		path = "C:/projetos/WS/aamoeditor/saida.xml";
		boolean resultado = XMLinterface.writeXML(path, screen);
		assertTrue(resultado);
	}

}
