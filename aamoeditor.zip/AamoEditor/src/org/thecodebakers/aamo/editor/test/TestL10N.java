package org.thecodebakers.aamo.editor.test;

import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import org.thecodebakers.aamo.editor.ui.Editor;
import org.thecodebakers.aamo.editor.ui.L10NScreen;
import org.thecodebakers.aamo.editor.ui.SelectObserver;

public class TestL10N implements SelectObserver {

	public static void main(String[] args) {
		Editor editor = new Editor();
		editor.res = ResourceBundle.getBundle("org.thecodebakers.aamo.editor.resources.editor");
		editor.screenLeft = 100;
		editor.screenTop= 100;
		L10NScreen screen = new L10NScreen();
		screen.setEditor(editor);
		TestL10N t = new TestL10N();
		screen.setObserver(t);
		screen.initComponents();

	}

	@Override
	public void setResult(Object obj) {
		JOptionPane.showMessageDialog(null, obj);
		
	}

}
