package org.thecodebakers.aamo.editor.test;

import static org.junit.Assert.*;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.junit.Test;
import org.thecodebakers.aamo.editor.business.XMLinterface;
import org.thecodebakers.aamo.editor.model.Screen;
import org.xml.sax.SAXException;

public class TestXMLinterfaceRead {

	@Test
	public void testReadXML() throws SAXException, IOException, ParserConfigurationException {
		String path = "C:/projetos/WS/aamoeditor/ui.xml";
		Screen screen = XMLinterface.readXML(path);
		assertTrue(screen.getElements().size() > 0);
	}

}
