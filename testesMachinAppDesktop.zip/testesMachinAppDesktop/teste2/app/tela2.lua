-- teste para invocar outra tela
aamo.setGlobalParameter("p1", "TESTE")
aamo.loadScreen(2)

-- aamo.showMessage(aamo.getError())