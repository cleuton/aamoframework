texto = aamo.getTextField(1.0)

aamo.showMessage("Tela " .. aamo.getCurrentScreenId() .. " : " .. texto)