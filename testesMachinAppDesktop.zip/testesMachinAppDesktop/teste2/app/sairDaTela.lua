-- Sai da tela
aamo.showMessage(aamo.getGlobalParameter("p1"))
aamo.exitScreen()