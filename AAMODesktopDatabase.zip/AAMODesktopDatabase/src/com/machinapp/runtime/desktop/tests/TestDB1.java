package com.machinapp.runtime.desktop.tests;

import static org.junit.Assert.*;

import java.io.File;
import java.util.ArrayList;

import org.junit.Test;

import com.machinapp.runtime.desktop.sqlite.DBAdapter;
import com.machinapp.runtime.desktop.util.Context;

public class TestDB1 {

	@Test
	public void test1() {
		Context context = new Context();
		context.setAppPath(new File(this.getClass().getClassLoader().getResource("./app").getFile()));
		context.setDbPath(new File(this.getClass().getClassLoader().getResource("./app/bd").getFile()));
		DBAdapter adapter = new DBAdapter(context);
		adapter.openDatabase("contatos");
		adapter.execSQL("insert into contato (ID, nome, endereco, email) values (1,'fulano','rua x','fulano@endereco') ", new ArrayList<String>());
		adapter.closeDatabase("contatos");
	}

}
