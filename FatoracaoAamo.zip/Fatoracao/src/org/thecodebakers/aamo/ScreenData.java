package org.thecodebakers.aamo;

import android.widget.RelativeLayout;

public class ScreenData {
	public int uiid;
    public String title;
    public String onLoadScript;
    public String onEndScript; 
    public RelativeLayout dvLayout;
}
