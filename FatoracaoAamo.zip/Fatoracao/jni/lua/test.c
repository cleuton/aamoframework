#include "lobject.h"
#include "stdio.h"
int main() {
    printf("String: %d, Udata: %d\n", sizeof(TString), sizeof(Udata));
    return 0;
}
